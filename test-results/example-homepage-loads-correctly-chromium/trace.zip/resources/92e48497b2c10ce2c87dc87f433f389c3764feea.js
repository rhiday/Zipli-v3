(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/store/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript) <export useSupabaseDatabase as useDatabase>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function HomePage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { currentUser, isInitialized } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomePage.useEffect": ()=>{
            if (isInitialized) {
                if (!currentUser) {
                    // No user logged in, redirect to login
                    router.push('/auth/login');
                } else {
                    // Redirect based on user role
                    switch(currentUser.role){
                        case 'food_donor':
                            router.push('/donate');
                            break;
                        case 'food_receiver':
                            router.push('/receiver/dashboard');
                            break;
                        case 'city':
                            router.push('/city/dashboard');
                            break;
                        case 'terminals':
                            router.push('/terminal/dashboard');
                            break;
                        default:
                            // Fallback to feed if role is unknown
                            router.push('/feed');
                            break;
                    }
                }
            }
        }
    }["HomePage.useEffect"], [
        isInitialized,
        currentUser,
        router
    ]);
    // Show loading spinner while determining redirect
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-h-dvh items-center justify-center bg-cream",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-primary"
        }, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_s(HomePage, "G7HEcDoXCXg3cV8p6dIs0l2PqKs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"]
    ];
});
_c = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_page_tsx_b4090435._.js.map