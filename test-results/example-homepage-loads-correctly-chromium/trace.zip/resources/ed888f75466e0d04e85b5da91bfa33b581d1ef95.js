(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__82b25693._.css",
  "static/chunks/node_modules_@supabase_node-fetch_browser_ebbd8575.js",
  "static/chunks/src_c022b30c._.js",
  "static/chunks/node_modules_next_b2ec6af5._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_af562a27._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_8cdc29ac._.js"
],
    source: "dynamic"
});
