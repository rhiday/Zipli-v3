(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-client] (ecmascript) <locals>");
;
// Environment variables with fallbacks to prevent bundler errors
const supabaseUrl = ("TURBOPACK compile-time value", "https://vqtfcdnrgotgrnwwuryo.supabase.co") || 'https://vqtfcdnrgotgrnwwuryo.supabase.co';
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZxdGZjZG5yZ290Z3Jud3d1cnlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU5MDgzNzYsImV4cCI6MjA2MTQ4NDM3Nn0.I2Qqp8BNeCxNHT9T03sbMROy_eKqXenj9QFibCmXdgk") || '';
// Runtime validation for production
if ("TURBOPACK compile-time truthy", 1) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
}
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey, {
    auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: 'pkce'
    },
    realtime: {
        params: {
            eventsPerSecond: 10
        }
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth/authService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// =====================================================
// AUTHENTICATION SERVICE LAYER
// Handles all authentication operations with Supabase Auth
// =====================================================
__turbopack_context__.s([
    "authService",
    ()=>authService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
;
class AuthService {
    /**
   * Sign up a new user with profile data
   */ async signUp(data) {
        try {
            var _authData_user, _this, _this1;
            console.log('🔐 AuthService.signUp - Starting signup with:', {
                email: data.email,
                userData: data.userData
            });
            const { data: authData, error: authError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.signUp({
                email: data.email,
                password: data.password,
                options: {
                    data: {
                        ...data.userData
                    }
                }
            });
            console.log('🔐 AuthService.signUp - Supabase response:', {
                hasUser: !!(authData === null || authData === void 0 ? void 0 : authData.user),
                userId: authData === null || authData === void 0 ? void 0 : (_authData_user = authData.user) === null || _authData_user === void 0 ? void 0 : _authData_user.id,
                error: authError,
                errorMessage: authError === null || authError === void 0 ? void 0 : authError.message,
                errorStatus: (_this = authError) === null || _this === void 0 ? void 0 : _this.status,
                errorCode: (_this1 = authError) === null || _this1 === void 0 ? void 0 : _this1.code
            });
            if (authError) {
                var _this2, _this3, _this4, _this5;
                console.error('🔐 AuthService.signUp - Auth error details:', {
                    message: authError.message,
                    status: (_this2 = authError) === null || _this2 === void 0 ? void 0 : _this2.status,
                    code: (_this3 = authError) === null || _this3 === void 0 ? void 0 : _this3.code,
                    details: (_this4 = authError) === null || _this4 === void 0 ? void 0 : _this4.details,
                    hint: (_this5 = authError) === null || _this5 === void 0 ? void 0 : _this5.hint,
                    fullError: authError
                });
                return {
                    data: null,
                    error: authError.message
                };
            }
            if (!authData.user) {
                console.error('🔐 AuthService.signUp - No user returned from Supabase');
                return {
                    data: null,
                    error: 'Failed to create user'
                };
            }
            // Get the created profile (created by database trigger)
            console.log('🔐 AuthService.signUp - Fetching profile for user:', authData.user.id);
            const profile = await this.getProfile(authData.user.id);
            if (!profile) {
                console.error('🔐 AuthService.signUp - Profile not found after signup');
                return {
                    data: null,
                    error: 'Failed to create user profile'
                };
            }
            console.log('🔐 AuthService.signUp - Success! Profile:', profile);
            return {
                data: profile,
                error: null
            };
        } catch (error) {
            console.error('🔐 AuthService.signUp - Caught exception:', error);
            return {
                data: null,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Sign in an existing user
   */ async signIn(data) {
        try {
            const { data: authData, error: authError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.signInWithPassword({
                email: data.email,
                password: data.password
            });
            if (authError) {
                return {
                    data: null,
                    error: authError.message
                };
            }
            if (!authData.user) {
                return {
                    data: null,
                    error: 'Failed to sign in'
                };
            }
            // Get the user's profile
            const profile = await this.getProfile(authData.user.id);
            if (!profile) {
                return {
                    data: null,
                    error: 'User profile not found'
                };
            }
            return {
                data: profile,
                error: null
            };
        } catch (error) {
            return {
                data: null,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Sign out the current user
   */ async signOut() {
        try {
            const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.signOut();
            return {
                error: (error === null || error === void 0 ? void 0 : error.message) || null
            };
        } catch (error) {
            return {
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Get current user session and profile
   */ async getCurrentUser() {
        try {
            const { data: { user } } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.getUser();
            if (!user) {
                return null;
            }
            // Only fetch needed fields in auth service
            const { data: profileData } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('profiles').select('id, email, full_name, organization_name, role') // Only essential fields
            .eq('id', user.id).single();
            return profileData;
        } catch (error) {
            console.error('Error getting current user', error);
            return null;
        }
    }
    /**
   * Get user profile by ID
   */ async getProfile(userId) {
        try {
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('profiles').select('*').eq('id', userId).single();
            if (error) {
                console.error('Error fetching profile', error);
                return null;
            }
            return data;
        } catch (error) {
            console.error('Error getting profile', error);
            return null;
        }
    }
    /**
   * Update user profile
   */ async updateProfile(userId, updates) {
        try {
            // Validate required fields
            if (!userId) {
                return {
                    data: null,
                    error: 'User ID is required'
                };
            }
            // Remove undefined values from updates
            const cleanUpdates = Object.fromEntries(Object.entries(updates).filter((param)=>{
                let [_, v] = param;
                return v !== undefined;
            }));
            // Ensure updated_at is set
            cleanUpdates.updated_at = new Date().toISOString();
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('profiles').update(cleanUpdates).eq('id', userId).select('*') // Explicitly select all fields
            .single();
            if (error) {
                console.error('Supabase update error:', error);
                return {
                    data: null,
                    error: error.message
                };
            }
            if (!data) {
                return {
                    data: null,
                    error: 'Profile not found'
                };
            }
            // Validate returned data
            if (!data.id || !data.email || !data.role) {
                console.error('Invalid profile data returned:', data);
                return {
                    data: null,
                    error: 'Invalid profile data returned from server'
                };
            }
            return {
                data,
                error: null
            };
        } catch (error) {
            console.error('Profile update error:', error);
            return {
                data: null,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Reset password
   */ async resetPassword(email) {
        try {
            const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.resetPasswordForEmail(email, {
                redirectTo: "".concat(window.location.origin, "/auth/reset-password")
            });
            return {
                error: (error === null || error === void 0 ? void 0 : error.message) || null
            };
        } catch (error) {
            return {
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Update password
   */ async updatePassword(newPassword) {
        try {
            const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.updateUser({
                password: newPassword
            });
            return {
                error: (error === null || error === void 0 ? void 0 : error.message) || null
            };
        } catch (error) {
            return {
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Verify OTP (for email confirmation, password reset, etc.)
   */ async verifyOtp(email, token, type) {
        try {
            const { data: authData, error: authError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.verifyOtp({
                email,
                token,
                type
            });
            if (authError) {
                return {
                    data: null,
                    error: authError.message
                };
            }
            if (!authData.user) {
                return {
                    data: null,
                    error: 'Failed to verify OTP'
                };
            }
            const profile = await this.getProfile(authData.user.id);
            if (!profile) {
                return {
                    data: null,
                    error: 'User profile not found'
                };
            }
            return {
                data: profile,
                error: null
            };
        } catch (error) {
            return {
                data: null,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
    /**
   * Check if user has specific role
   */ hasRole(user, role) {
        return (user === null || user === void 0 ? void 0 : user.role) === role;
    }
    /**
   * Check if user is admin (city or terminals)
   */ isAdmin(user) {
        return (user === null || user === void 0 ? void 0 : user.role) === 'city' || (user === null || user === void 0 ? void 0 : user.role) === 'terminals';
    }
    /**
   * Listen for auth state changes
   */ onAuthStateChange(callback) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.onAuthStateChange(async (event, session)=>{
            if (session === null || session === void 0 ? void 0 : session.user) {
                const profile = await this.getProfile(session.user.id);
                callback(profile);
            } else {
                callback(null);
            }
        });
    }
    /**
   * Get current session
   */ async getSession() {
        try {
            const { data: { session } } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.getSession();
            return session;
        } catch (error) {
            console.error('Error getting session', error);
            return null;
        }
    }
    /**
   * Development helper: Quick login with email (for testing)
   */ async devLogin(email) {
        // In development, we'll simulate login by finding the user profile
        try {
            const { data: profile, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('profiles').select('*').ilike('full_name', "%".concat(email.split('@')[0], "%")).single();
            if (error || !profile) {
                return {
                    data: null,
                    error: 'User not found'
                };
            }
            return {
                data: profile,
                error: null
            };
        } catch (error) {
            return {
                data: null,
                error: error instanceof Error ? error.message : 'Unknown error occurred'
            };
        }
    }
}
const authService = new AuthService();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth/sessionUtils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// =====================================================
// SESSION UTILITIES
// Handles "Remember Me" functionality at application level
// =====================================================
__turbopack_context__.s([
    "clearRememberMePreference",
    ()=>clearRememberMePreference,
    "clearRememberedEmail",
    ()=>clearRememberedEmail,
    "getRememberMePreference",
    ()=>getRememberMePreference,
    "getRememberedEmail",
    ()=>getRememberedEmail,
    "getSessionTimestamp",
    ()=>getSessionTimestamp,
    "initializeSessionTracking",
    ()=>initializeSessionTracking,
    "setRememberMePreference",
    ()=>setRememberMePreference,
    "setRememberedEmail",
    ()=>setRememberedEmail,
    "setSessionTimestamp",
    ()=>setSessionTimestamp,
    "shouldMaintainSession",
    ()=>shouldMaintainSession
]);
const REMEMBER_ME_KEY = 'zipli_remember_me';
const SESSION_TIMESTAMP_KEY = 'zipli_session_timestamp';
const REMEMBERED_EMAIL_KEY = 'zipli_remembered_email';
function setRememberMePreference(rememberMe) {
    try {
        const preference = {
            rememberMe,
            timestamp: Date.now()
        };
        localStorage.setItem(REMEMBER_ME_KEY, JSON.stringify(preference));
    } catch (error) {
        console.warn('Failed to store remember me preference:', error);
    }
}
function getRememberMePreference() {
    try {
        const stored = localStorage.getItem(REMEMBER_ME_KEY);
        if (!stored) return null;
        return JSON.parse(stored);
    } catch (error) {
        console.warn('Failed to read remember me preference:', error);
        return null;
    }
}
function shouldMaintainSession() {
    const preference = getRememberMePreference();
    // If no preference stored, default to maintaining session (backward compatibility)
    if (!preference) return true;
    // If user chose to be remembered, maintain session
    if (preference.rememberMe) return true;
    // If user chose not to be remembered, check if this is a new browser session
    // We consider it a new session if there's no session timestamp or it's very old
    const sessionTimestamp = getSessionTimestamp();
    const now = Date.now();
    // If no session timestamp, this might be a new browser session
    if (!sessionTimestamp) return false;
    // If the session timestamp is older than 30 minutes and remember me is false,
    // consider this a new session (user likely closed and reopened browser)
    const timeDifference = now - sessionTimestamp;
    const thirtyMinutes = 30 * 60 * 1000;
    return timeDifference <= thirtyMinutes;
}
function setSessionTimestamp() {
    try {
        sessionStorage.setItem(SESSION_TIMESTAMP_KEY, Date.now().toString());
    } catch (error) {
        console.warn('Failed to set session timestamp:', error);
    }
}
function getSessionTimestamp() {
    try {
        const timestamp = sessionStorage.getItem(SESSION_TIMESTAMP_KEY);
        return timestamp ? parseInt(timestamp, 10) : null;
    } catch (error) {
        console.warn('Failed to read session timestamp:', error);
        return null;
    }
}
function clearRememberMePreference() {
    try {
        localStorage.removeItem(REMEMBER_ME_KEY);
        localStorage.removeItem(REMEMBERED_EMAIL_KEY);
        sessionStorage.removeItem(SESSION_TIMESTAMP_KEY);
    } catch (error) {
        console.warn('Failed to clear remember me preference:', error);
    }
}
function initializeSessionTracking() {
    setSessionTimestamp();
}
function setRememberedEmail(email, rememberMe) {
    try {
        if (rememberMe) {
            localStorage.setItem(REMEMBERED_EMAIL_KEY, email);
        } else {
            // If remember me is false, clear any previously stored email
            localStorage.removeItem(REMEMBERED_EMAIL_KEY);
        }
    } catch (error) {
        console.warn('Failed to store remembered email:', error);
    }
}
function getRememberedEmail() {
    try {
        return localStorage.getItem(REMEMBERED_EMAIL_KEY) || '';
    } catch (error) {
        console.warn('Failed to retrieve remembered email:', error);
        return '';
    }
}
function clearRememberedEmail() {
    try {
        localStorage.removeItem(REMEMBERED_EMAIL_KEY);
    } catch (error) {
        console.warn('Failed to clear remembered email:', error);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/database/queryOptimizer.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Query Optimizer for Supabase Database Calls
 * Reduces over-fetching and implements request deduplication
 * 
 * Based on network analysis findings:
 * - Reduce profile field over-fetching (from ~2.4kB to ~0.5kB per donation)
 * - Implement request caching to prevent duplicate API calls
 * - Add field-specific selects to minimize payload sizes
 */ __turbopack_context__.s([
    "batchFetchUserData",
    ()=>batchFetchUserData,
    "clearQueryCache",
    ()=>clearQueryCache,
    "fetchOptimizedDonations",
    ()=>fetchOptimizedDonations,
    "fetchOptimizedRequests",
    ()=>fetchOptimizedRequests,
    "getCacheStats",
    ()=>getCacheStats
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
;
// Cache for request deduplication
const queryCache = new Map();
// Cache TTL configurations (in milliseconds)
const CACHE_CONFIGS = {
    donations: 30000,
    requests: 60000,
    profiles: 300000
};
/**
 * Generic cache handler with TTL support
 */ function getCachedResult(cacheKey, ttl) {
    const cached = queryCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < cached.ttl) {
        console.log("📄 Cache hit for ".concat(cacheKey));
        return cached.data;
    }
    return null;
}
function setCachedResult(cacheKey, data, ttl) {
    queryCache.set(cacheKey, {
        data,
        timestamp: Date.now(),
        ttl
    });
}
async function fetchOptimizedDonations(currentUser) {
    let limit = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 20;
    // Return empty array if no user is logged in
    if (!currentUser) {
        console.log('📊 No user logged in, returning empty donations array');
        return [];
    }
    const cacheKey = "donations:".concat(currentUser.id, ":").concat(currentUser.role, ":").concat(limit);
    // Check cache first
    const cached = getCachedResult(cacheKey, CACHE_CONFIGS.donations);
    if (cached) return cached;
    let query = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('donations').select("\n      *,\n      food_item:food_items(*),\n      donor:profiles!donations_donor_id_fkey(\n        id,\n        full_name,\n        role\n      )\n    ").order('created_at', {
        ascending: false
    }).limit(limit);
    // Apply role-based filtering (same logic as original)
    if (currentUser.role === 'food_donor') {
        query = query.eq('donor_id', currentUser.id);
    } else if (currentUser.role === 'food_receiver') {
        query = query.eq('status', 'available');
    }
    const { data, error } = await query;
    if (error) {
        console.error('Error fetching optimized donations:', error);
        throw error;
    }
    const donations = (data || []).map((donation)=>({
            ...donation,
            food_item: donation.food_item || null,
            donor: donation.donor || null
        }));
    // Cache the result
    setCachedResult(cacheKey, donations, CACHE_CONFIGS.donations);
    console.log("📊 Fetched ".concat(donations.length, " donations with optimized queries"));
    return donations;
}
async function fetchOptimizedRequests(currentUser) {
    // Return empty array if no user is logged in
    if (!currentUser) {
        console.log('📊 No user logged in, returning empty requests array');
        return [];
    }
    const cacheKey = "requests:".concat(currentUser.id, ":").concat(currentUser.role);
    // Check cache first
    const cached = getCachedResult(cacheKey, CACHE_CONFIGS.requests);
    if (cached) return cached;
    let query = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('requests').select('*').order('created_at', {
        ascending: false
    });
    // Apply role-based filtering (same logic as original)
    if (currentUser.role === 'food_receiver') {
        query = query.eq('user_id', currentUser.id);
    } else if (currentUser.role === 'food_donor') {
        query = query.eq('status', 'active');
    }
    const { data, error } = await query;
    if (error) {
        console.error('Error fetching optimized requests:', error);
        throw error;
    }
    const requests = data || [];
    // Cache the result
    setCachedResult(cacheKey, requests, CACHE_CONFIGS.requests);
    console.log("📊 Fetched ".concat(requests.length, " requests with caching"));
    return requests;
}
async function batchFetchUserData(currentUser) {
    console.log('🚀 Starting batch data fetch...');
    // Return empty arrays if no user is logged in
    if (!currentUser) {
        console.log('📊 No user logged in, returning empty data arrays');
        return {
            donations: [],
            requests: []
        };
    }
    // Fetch donations
    const donations = await fetchOptimizedDonations(currentUser);
    // Fetch requests if user is not a food_donor
    let requests = [];
    if (currentUser.role !== 'food_donor') {
        requests = await fetchOptimizedRequests(currentUser);
    }
    console.log('✅ Batch data fetch completed');
    return {
        donations,
        requests
    };
}
function clearQueryCache(pattern) {
    if (pattern) {
        // Clear specific cache entries matching pattern
        for (const [key] of queryCache){
            if (key.includes(pattern)) {
                queryCache.delete(key);
            }
        }
    } else {
        // Clear all cache
        queryCache.clear();
    }
    console.log("🗑️ Cleared query cache".concat(pattern ? " (pattern: ".concat(pattern, ")") : ''));
}
function getCacheStats() {
    return {
        totalEntries: queryCache.size,
        hitRate: 0,
        memoryUsage: "~".concat(queryCache.size * 0.5, "KB")
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// =====================================================
// SUPABASE DATABASE STORE
// Replaces mock database store with real Supabase backend
// =====================================================
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useSupabaseDatabase",
    ()=>useSupabaseDatabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth/authService.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$sessionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth/sessionUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2f$queryOptimizer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/database/queryOptimizer.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const useSupabaseDatabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set, get)=>({
        // Initial state
        donations: [],
        foodItems: [],
        users: [],
        requests: [],
        currentUser: null,
        isInitialized: false,
        loading: false,
        error: null,
        subscriptions: [],
        // Utility methods
        setLoading: (loading)=>set({
                loading
            }),
        setError: (error)=>set({
                error
            }),
        // ===== INITIALIZATION =====
        init: async ()=>{
            const state = get();
            if (state.isInitialized) {
                return;
            }
            try {
                console.log('🚀 Store init starting...');
                set({
                    loading: true,
                    error: null
                });
                // Initialize session tracking
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$sessionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initializeSessionTracking"])();
                // Check for existing session
                console.log('📋 Getting current user...');
                const currentUser = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].getCurrentUser();
                console.log('👤 Current user:', (currentUser === null || currentUser === void 0 ? void 0 : currentUser.full_name) || 'None');
                // Check if we should maintain this session based on remember me preference
                if (currentUser && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$sessionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldMaintainSession"])()) {
                    console.log('🚪 Remember Me was disabled, logging out...');
                    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].signOut();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$sessionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearRememberMePreference"])();
                    set({
                        currentUser: null,
                        isInitialized: true,
                        loading: false
                    });
                    return;
                }
                if (currentUser) {
                    // Use optimized batch data fetching
                    console.log('📦 Starting optimized batch data fetch...');
                    const { donations, requests } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2f$queryOptimizer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["batchFetchUserData"])(currentUser);
                    // Update state with fetched data
                    set({
                        donations,
                        requests,
                        users: [
                            currentUser
                        ],
                        currentUser,
                        isInitialized: true,
                        loading: false
                    });
                    console.log('✅ Optimized data fetching completed');
                } else {
                    // No user logged in - just set empty state
                    set({
                        donations: [],
                        requests: [],
                        users: [],
                        currentUser: null,
                        isInitialized: true,
                        loading: false
                    });
                }
                // Setup real-time subscriptions
                // Move real-time setup to after UI is ready
                // Defer real-time setup
                setTimeout(()=>{
                    state.setupRealtimeSubscriptions();
                }, 100);
            } catch (error) {
                console.error('Initialization error', error);
                set({
                    error: error instanceof Error ? error.message : 'Initialization failed',
                    loading: false
                });
            }
        },
        // ===== AUTHENTICATION METHODS =====
        login: async (email, password)=>{
            try {
                set({
                    loading: true,
                    error: null
                });
                // Always use real Supabase authentication
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].signIn({
                    email,
                    password
                });
                if (result.data) {
                    set({
                        currentUser: result.data
                    });
                    // Refresh data after login
                    await get().fetchDonations();
                    // Only fetch requests if user is not a food_donor
                    if (result.data.role !== 'food_donor') {
                        await get().fetchRequests();
                    }
                }
                set({
                    loading: false
                });
                return result;
            } catch (error) {
                set({
                    loading: false
                });
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Login failed'
                };
            }
        },
        register: async (email, password, userData)=>{
            try {
                console.log('📝 Store.register - Starting registration for:', email);
                console.log('📝 Store.register - User data:', userData);
                set({
                    loading: true,
                    error: null
                });
                const signUpData = {
                    email,
                    password,
                    userData: {
                        role: userData.role || 'food_receiver',
                        full_name: userData.full_name || email,
                        organization_name: userData.organization_name || undefined,
                        contact_number: userData.contact_number || undefined,
                        address: userData.address || undefined
                    }
                };
                console.log('📝 Store.register - Calling authService.signUp with:', signUpData);
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].signUp(signUpData);
                console.log('📝 Store.register - Auth service result:', {
                    hasData: !!result.data,
                    error: result.error,
                    userData: result.data
                });
                if (result.data) {
                    console.log('📝 Store.register - Setting current user:', result.data);
                    set({
                        currentUser: result.data
                    });
                } else if (result.error) {
                    console.error('📝 Store.register - Registration failed:', result.error);
                }
                set({
                    loading: false
                });
                return result;
            } catch (error) {
                console.error('📝 Store.register - Caught exception:', error);
                set({
                    loading: false
                });
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Registration failed'
                };
            }
        },
        resetPassword: async (email)=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].resetPassword(email);
        },
        updatePassword: async (password)=>{
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].updatePassword(password);
        },
        verifyOtp: async (email, token, type)=>{
            const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].verifyOtp(email, token, type);
            if (result.data) {
                set({
                    currentUser: result.data
                });
            }
            return result;
        },
        setCurrentUser: async (email)=>{
            // For development compatibility - find user by email
            const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].devLogin(email);
            if (result.data) {
                set({
                    currentUser: result.data
                });
            }
        },
        updateUser: async (updatedUser)=>{
            try {
                console.log('🔄 updateUser called with:', updatedUser);
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].updateProfile(updatedUser.id, updatedUser);
                console.log('🔄 updateProfile result:', result);
                if (result.error) {
                    console.error('❌ Profile update failed:', result.error);
                    throw new Error(result.error);
                }
                if (result.data) {
                    console.log('✅ Profile updated successfully, updating state');
                    set({
                        currentUser: result.data
                    });
                } else {
                    throw new Error('No data returned from profile update');
                }
            } catch (error) {
                console.error('❌ Error in updateUser:', error);
                throw error; // Re-throw so the UI can handle it
            }
        },
        logout: async ()=>{
            try {
                // Always sign out from Supabase
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$authService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authService"].signOut();
                // Clear remember me preferences
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2f$sessionUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearRememberMePreference"])();
                get().cleanupSubscriptions();
                set({
                    currentUser: null,
                    // Keep users list for DevLoginSwitcher
                    // Other data will be cleared
                    donations: [],
                    requests: []
                });
            } catch (error) {
                console.error('Logout error', error);
            }
        },
        // ===== DATA FETCHING METHODS =====
        fetchDonations: async ()=>{
            try {
                const currentUser = get().currentUser;
                // Check if user is authenticated
                if (!currentUser) {
                    console.log('No authenticated user, skipping donations fetch');
                    set({
                        donations: []
                    });
                    return;
                }
                // Use optimized query with caching and reduced over-fetching
                const donations = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2f$queryOptimizer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchOptimizedDonations"])(currentUser, 50);
                set({
                    donations
                });
            } catch (error) {
                console.error('Error fetching donations', error);
                set({
                    error: error instanceof Error ? error.message : 'Failed to fetch donations'
                });
            }
        },
        fetchFoodItems: async ()=>{
            try {
                // Only fetch food items that are actually used
                const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('food_items').select('id, name, description, allergens') // Only needed fields
                .order('name').limit(100); // Limit to 100 items
                if (data === null) throw new Error('No food items found');
                set({
                    foodItems: data || []
                });
            } catch (error) {
                console.error('Error fetching food items', error);
                set({
                    error: error instanceof Error ? error.message : 'Failed to fetch food items'
                });
            }
        },
        fetchUsers: async ()=>{
            const currentUser = get().currentUser;
            if (currentUser) {
                // Just use current user data, don't fetch all profiles
                set({
                    users: [
                        currentUser
                    ]
                });
                return;
            }
            try {
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('profiles').select('id, full_name, organization_name') // Only 3 fields
                .order('full_name');
                if (error) throw error;
                set({
                    users: data || []
                });
            } catch (error) {
                console.error('Error fetching user display names', error);
                set({
                    error: error instanceof Error ? error.message : 'Failed to fetch users'
                });
            }
        },
        fetchRequests: async ()=>{
            try {
                const currentUser = get().currentUser;
                // Check if user is authenticated
                if (!currentUser) {
                    console.log('No authenticated user, skipping requests fetch');
                    set({
                        requests: []
                    });
                    return;
                }
                // Use optimized query with caching
                const requests = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2f$queryOptimizer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchOptimizedRequests"])(currentUser);
                set({
                    requests
                });
            } catch (error) {
                console.error('Error fetching requests', error);
                set({
                    error: error instanceof Error ? error.message : 'Failed to fetch requests'
                });
            }
        },
        fetchDonationById: async (id)=>{
            try {
                const currentUser = get().currentUser;
                // Check if user is authenticated
                if (!currentUser) {
                    console.log('No authenticated user, cannot fetch donation');
                    return {
                        data: null,
                        error: 'Not authenticated'
                    };
                }
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('donations').select("\n              *,\n              food_item:food_items(*),\n              donor:profiles!donations_donor_id_fkey(*)\n            ").eq('id', id).single();
                if (error) {
                    console.error('Error fetching donation by ID:', error);
                    return {
                        data: null,
                        error: error.message
                    };
                }
                if (!data) {
                    return {
                        data: null,
                        error: 'Donation not found'
                    };
                }
                // Check if user has permission to view this donation
                const canView = currentUser.role === 'city' || currentUser.role === 'terminals' || data.donor_id === currentUser.id || currentUser.role === 'food_receiver' && data.status === 'available';
                if (!canView) {
                    return {
                        data: null,
                        error: 'Access denied'
                    };
                }
                const donation = {
                    ...data,
                    food_item: data.food_item || null,
                    donor: data.donor || null
                };
                return {
                    data: donation,
                    error: null
                };
            } catch (error) {
                console.error('Error fetching donation by ID:', error);
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to fetch donation'
                };
            }
        },
        // ===== DONATION METHODS =====
        getDonationById: (id)=>{
            return get().donations.find((d)=>d.id === id);
        },
        getDonationsByDonor: (donorId)=>{
            return get().donations.filter((d)=>d.donor_id === donorId);
        },
        getAllDonations: ()=>{
            return get().donations;
        },
        addDonation: async (donation)=>{
            try {
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('donations').insert(donation).select().single();
                if (error) return {
                    data: null,
                    error: error.message
                };
                // Refresh donations to get the full data with relations
                await get().fetchDonations();
                return {
                    data,
                    error: null
                };
            } catch (error) {
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to add donation'
                };
            }
        },
        updateDonation: async (id, updates)=>{
            try {
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('donations').update(updates).eq('id', id).select().single();
                if (error) return {
                    data: null,
                    error: error.message
                };
                // Refresh donations
                await get().fetchDonations();
                return {
                    data,
                    error: null
                };
            } catch (error) {
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to update donation'
                };
            }
        },
        deleteDonation: async (id)=>{
            try {
                // First, get the donation to find the food_item_id
                const donationToDelete = get().donations.find((d)=>d.id === id);
                if (!donationToDelete) {
                    return {
                        error: 'Donation not found'
                    };
                }
                // Delete the donation first (this is the main operation)
                const { error: donationError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('donations').delete().eq('id', id);
                if (donationError) return {
                    error: donationError.message
                };
                // Then try to delete the associated food item
                // This is safe because if the food item is referenced elsewhere, it will fail silently
                const { error: foodItemError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('food_items').delete().eq('id', donationToDelete.food_item_id);
                // Log food item deletion error but don't fail the operation
                if (foodItemError) {
                    console.log('Food item deletion skipped (may be referenced elsewhere):', foodItemError.message);
                }
                // Remove from local state
                const donations = get().donations.filter((d)=>d.id !== id);
                const foodItems = foodItemError ? get().foodItems // Keep food items if deletion failed
                 : get().foodItems.filter((fi)=>fi.id !== donationToDelete.food_item_id);
                set({
                    donations,
                    foodItems
                });
                return {
                    error: null
                };
            } catch (error) {
                return {
                    error: error instanceof Error ? error.message : 'Failed to delete donation'
                };
            }
        },
        // ===== FOOD ITEM METHODS =====
        addFoodItem: async (foodItem)=>{
            try {
                // Ensure image_urls is properly formatted as JSON array if provided
                const processedFoodItem = {
                    ...foodItem,
                    image_urls: foodItem.image_urls || []
                };
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('food_items').insert(processedFoodItem).select().single();
                if (error) return {
                    data: null,
                    error: error.message
                };
                // Add to local state
                const foodItems = [
                    ...get().foodItems,
                    data
                ];
                set({
                    foodItems
                });
                return {
                    data,
                    error: null
                };
            } catch (error) {
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to add food item'
                };
            }
        },
        updateFoodItem: async (id, updates)=>{
            try {
                // Ensure image_urls is properly formatted if provided
                const processedUpdates = {
                    ...updates
                };
                // If image_urls is provided, ensure it's formatted correctly
                if (updates.image_urls !== undefined) {
                    processedUpdates.image_urls = updates.image_urls || [];
                }
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('food_items').update(processedUpdates).eq('id', id).select().single();
                if (error) return {
                    data: null,
                    error: error.message
                };
                // Update local state
                const foodItems = get().foodItems.map((item)=>item.id === id ? {
                        ...item,
                        ...data
                    } : item);
                set({
                    foodItems
                });
                return {
                    data,
                    error: null
                };
            } catch (error) {
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to update food item'
                };
            }
        },
        // ===== REQUEST METHODS =====
        getAllRequests: ()=>{
            return get().requests;
        },
        getRequestById: (id)=>{
            return get().requests.find((r)=>r.id === id);
        },
        addRequest: async (requestData)=>{
            try {
                // Ensure allergens is properly formatted as array for PostgreSQL
                const formattedRequest = {
                    ...requestData,
                    allergens: Array.isArray(requestData.allergens) ? requestData.allergens : requestData.allergens ? [
                        requestData.allergens
                    ] : null
                };
                console.log('🔧 Supabase insert payload:', formattedRequest);
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('requests').insert(formattedRequest).select().single();
                if (error) return {
                    data: null,
                    error: error.message
                };
                // Add to local state
                const requests = [
                    data,
                    ...get().requests
                ];
                set({
                    requests
                });
                return {
                    data,
                    error: null
                };
            } catch (error) {
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to add request'
                };
            }
        },
        updateRequest: async (id, updates)=>{
            try {
                const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('requests').update(updates).eq('id', id).select().single();
                if (error) return {
                    data: null,
                    error: error.message
                };
                // Update local state
                const requests = get().requests.map((req)=>req.id === id ? {
                        ...req,
                        ...data
                    } : req);
                set({
                    requests
                });
                return {
                    data,
                    error: null
                };
            } catch (error) {
                return {
                    data: null,
                    error: error instanceof Error ? error.message : 'Failed to update request'
                };
            }
        },
        deleteRequest: async (id)=>{
            try {
                const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('requests').delete().eq('id', id);
                if (error) return {
                    error: error.message
                };
                // Remove from local state
                const requests = get().requests.filter((r)=>r.id !== id);
                set({
                    requests
                });
                return {
                    error: null
                };
            } catch (error) {
                return {
                    error: error instanceof Error ? error.message : 'Failed to delete request'
                };
            }
        },
        // ===== REAL-TIME METHODS =====
        setupRealtimeSubscriptions: ()=>{
            // Clean up any existing subscriptions first
            const currentState = get();
            if (currentState.subscriptions.length > 0) {
                console.log('Cleaning up existing subscriptions...');
                currentState.cleanupSubscriptions();
            }
            const subscriptions = [];
            try {
                // OPTIMIZED: Use stable channel names to prevent memory leaks
                // Only refetch if user is affected by the change
                const donationsChannel = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].channel('donations_realtime').on('postgres_changes', {
                    event: '*',
                    schema: 'public',
                    table: 'donations'
                }, (payload)=>{
                    var _this;
                    console.log('Donations changed:', payload.eventType, (_this = payload.new) === null || _this === void 0 ? void 0 : _this.id);
                    // PERFORMANCE: Only refetch if current user is involved
                    const currentUser = get().currentUser;
                    if (!currentUser) return;
                    const newRecord = payload.new;
                    const oldRecord = payload.old;
                    const relevantChange = (newRecord === null || newRecord === void 0 ? void 0 : newRecord.donor_id) === currentUser.id || (oldRecord === null || oldRecord === void 0 ? void 0 : oldRecord.donor_id) === currentUser.id || payload.eventType === 'DELETE'; // Always refetch on deletes
                    if (relevantChange) {
                        // Debounce rapid changes
                        clearTimeout(window._donationRefetchTimeout);
                        window._donationRefetchTimeout = setTimeout(()=>{
                            // Clear cache for fresh data after real-time update
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2f$queryOptimizer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearQueryCache"])('donations');
                            get().fetchDonations();
                        }, 100);
                    }
                }).subscribe();
                // Only set up requests subscription if user is not a food_donor
                const currentUser = get().currentUser;
                if ((currentUser === null || currentUser === void 0 ? void 0 : currentUser.role) !== 'food_donor') {
                    const requestsChannel = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].channel('requests_realtime').on('postgres_changes', {
                        event: '*',
                        schema: 'public',
                        table: 'requests'
                    }, (payload)=>{
                        var _this;
                        console.log('Requests changed:', payload.eventType, (_this = payload.new) === null || _this === void 0 ? void 0 : _this.id);
                        const currentUser = get().currentUser;
                        if (!currentUser) return;
                        const newRecord = payload.new;
                        const oldRecord = payload.old;
                        const relevantChange = (newRecord === null || newRecord === void 0 ? void 0 : newRecord.user_id) === currentUser.id || (oldRecord === null || oldRecord === void 0 ? void 0 : oldRecord.user_id) === currentUser.id || payload.eventType === 'DELETE';
                        if (relevantChange) {
                            clearTimeout(window._requestRefetchTimeout);
                            window._requestRefetchTimeout = setTimeout(()=>{
                                // Clear cache for fresh data after real-time update
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2f$queryOptimizer$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearQueryCache"])('requests');
                                get().fetchRequests();
                            }, 100);
                        }
                    }).subscribe();
                    subscriptions.push(requestsChannel);
                }
                subscriptions.push(donationsChannel);
                set({
                    subscriptions
                });
                console.log('Optimized real-time subscriptions set up successfully');
            } catch (error) {
                console.error('Error setting up subscriptions', error);
            }
        },
        cleanupSubscriptions: ()=>{
            const { subscriptions } = get();
            subscriptions.forEach((subscription)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].removeChannel(subscription);
            });
            set({
                subscriptions: []
            });
        }
    }), {
    name: 'supabase-database-storage',
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
    // Only persist user session, not the actual data (we'll fetch fresh data on init)
    partialize: (state)=>({
            currentUser: state.currentUser
        })
}));
const __TURBOPACK__default__export__ = useSupabaseDatabase;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/store/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// =====================================================
// DATABASE STORE EXPORT
// Central export point for database store
// =====================================================
// Import the new Supabase-powered store
__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript) <export useSupabaseDatabase as useDatabase>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDatabase",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSupabaseDatabase"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript)");
}),
"[project]/src/components/auth/AuthProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * AuthProvider
 * Provides authentication context and handles user session management
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/store/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript) <export useSupabaseDatabase as useDatabase>");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const AuthProvider = (param)=>{
    let { children } = param;
    _s();
    const currentUser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])({
        "AuthProvider.useDatabase[currentUser]": (state)=>state.currentUser
    }["AuthProvider.useDatabase[currentUser]"]);
    const isInitialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])({
        "AuthProvider.useDatabase[isInitialized]": (state)=>state.isInitialized
    }["AuthProvider.useDatabase[isInitialized]"]);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])({
        "AuthProvider.useDatabase[logout]": (state)=>state.logout
    }["AuthProvider.useDatabase[logout]"]);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            if (isInitialized) {
                setIsLoading(false);
            }
        }
    }["AuthProvider.useEffect"], [
        isInitialized
    ]);
    const handleSignOut = ()=>{
        logout();
        router.push('/auth/login');
    };
    const value = {
        user: currentUser,
        session: null,
        isLoading: isLoading,
        signOut: handleSignOut
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/auth/AuthProvider.tsx",
        lineNumber: 53,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AuthProvider, "K5Tg4uJ77mSBw/5BwvC38K9CZwA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthProvider;
const useAuth = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn,
    "getInitials",
    ()=>getInitials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function getInitials(name) {
    if (!name) return '??';
    return name.split(' ').map((n)=>n[0]).filter(Boolean).join('').toUpperCase() || '??';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])('inline-flex items-center justify-center rounded-full font-semibold transition-colors focus:outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-interactive cursor-pointer gap-2.5 shrink-0 disabled:bg-inactive disabled:text-tertiary disabled:cursor-not-allowed', {
    variants: {
        variant: {
            primary: 'bg-positive text-black hover:bg-positive/90',
            secondary: 'bg-base border border-interactive text-interactive hover:bg-cloud',
            destructive: 'bg-negative !text-white hover:bg-negative/90',
            'destructive-outline': 'bg-white border border-negative text-negative hover:bg-negative/10 !text-negative',
            ghost: 'bg-transparent text-primary hover:bg-primary/10',
            tertiary: 'bg-transparent text-interactive border-b border-interactive rounded-none gap-1 hover:bg-interactive/10'
        },
        size: {
            sm: 'h-8 px-3 text-label rounded-sm',
            md: 'px-6 py-3 text-bodyLg',
            cta: 'h-[46px] p-[14px] gap-[6px] text-bodyLg font-semibold',
            lg: 'h-16 py-3.5 px-[22px] text-bodyLg'
        }
    },
    defaultVariants: {
        variant: 'primary',
        size: 'md'
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = (param, ref)=>{
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 43,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Button;
Button.displayName = 'Button';
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Button$React.forwardRef");
__turbopack_context__.k.register(_c1, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/drawer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Drawer",
    ()=>Drawer,
    "DrawerClose",
    ()=>DrawerClose,
    "DrawerContent",
    ()=>DrawerContent,
    "DrawerDescription",
    ()=>DrawerDescription,
    "DrawerFooter",
    ()=>DrawerFooter,
    "DrawerHeader",
    ()=>DrawerHeader,
    "DrawerOverlay",
    ()=>DrawerOverlay,
    "DrawerPortal",
    ()=>DrawerPortal,
    "DrawerTitle",
    ()=>DrawerTitle,
    "DrawerTrigger",
    ()=>DrawerTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/vaul/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const Drawer = (param)=>{
    let { shouldScaleBackground = false, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Root, {
        shouldScaleBackground: shouldScaleBackground,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Drawer;
Drawer.displayName = 'Drawer';
const DrawerTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Trigger;
const DrawerPortal = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Portal;
const DrawerClose = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Close;
const DrawerOverlay = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Overlay, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('fixed inset-0 z-50 bg-black/80', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 29,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = DrawerOverlay;
DrawerOverlay.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Overlay.displayName;
const DrawerContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = (param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DrawerPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DrawerOverlay, {}, void 0, false, {
                fileName: "[project]/src/components/ui/drawer.tsx",
                lineNumber: 42,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Content, {
                ref: ref,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('fixed inset-x-0 bottom-0 z-50 flex h-auto flex-col rounded-t-[10px] border bg-background max-w-lg mx-auto left-0 right-0', className),
                ...props,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/drawer.tsx",
                        lineNumber: 51,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/drawer.tsx",
                lineNumber: 43,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 41,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = DrawerContent;
DrawerContent.displayName = 'DrawerContent';
const DrawerHeader = (param)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('grid gap-1.5 p-4 text-center sm:text-left', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 62,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c4 = DrawerHeader;
DrawerHeader.displayName = 'DrawerHeader';
const DrawerFooter = (param)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('mt-auto flex flex-col gap-2 p-4', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 73,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c5 = DrawerFooter;
DrawerFooter.displayName = 'DrawerFooter';
const DrawerTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Title, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-lg font-semibold leading-none tracking-tight', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 84,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c7 = DrawerTitle;
DrawerTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Title.displayName;
const DrawerDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Description, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-sm text-muted-foreground', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/drawer.tsx",
        lineNumber: 99,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c9 = DrawerDescription;
DrawerDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$vaul$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"].Description.displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
__turbopack_context__.k.register(_c, "Drawer");
__turbopack_context__.k.register(_c1, "DrawerOverlay");
__turbopack_context__.k.register(_c2, "DrawerContent$React.forwardRef");
__turbopack_context__.k.register(_c3, "DrawerContent");
__turbopack_context__.k.register(_c4, "DrawerHeader");
__turbopack_context__.k.register(_c5, "DrawerFooter");
__turbopack_context__.k.register(_c6, "DrawerTitle$React.forwardRef");
__turbopack_context__.k.register(_c7, "DrawerTitle");
__turbopack_context__.k.register(_c8, "DrawerDescription$React.forwardRef");
__turbopack_context__.k.register(_c9, "DrawerDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useLanguage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useLanguageStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        language: 'fi',
        setLanguage: (language)=>set({
                language
            })
    }), {
    name: 'language-storage'
}));
const useLanguage = ()=>{
    _s();
    const { language, setLanguage } = useLanguageStore();
    // Temporary fallback t function for pages not yet updated
    const t = (key)=>{
        // Just return the key as fallback - actual translations are in the new system
        return key;
    };
    return {
        language,
        setLanguage,
        t
    };
};
_s(useLanguage, "Dn/v5vBJOIBnaMHx2smdS9qmUyc=", false, function() {
    return [
        useLanguageStore
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/translations/en.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// English translations - static file
// Updated manually as needed
__turbopack_context__.s([
    "en",
    ()=>en
]);
const en = {
    // Common actions
    add: 'Add',
    back: 'Back',
    cancel: 'Cancel',
    continue: 'Continue',
    delete: 'Delete',
    edit: 'Edit',
    save: 'Save',
    submit: 'Submit',
    loading: 'Loading...',
    // Dashboard
    dashboard: 'Dashboard',
    impact: 'Impact',
    analytics: 'Analytics',
    overview: 'Overview',
    donation: 'Listing',
    submitting: 'Submitting...',
    addDonation: 'Add Donation',
    explore: 'Explore',
    requestFood: 'Request Food',
    terminal: 'Terminal',
    createRequest: 'Create request',
    createSingleRequest: 'Create a single request for immediate needs',
    setupRepeatingSchedule: 'Set up a repeating schedule for ongoing needs',
    goodToSeeYou: "Hello! Let's turn food waste into impact.",
    // Impact metrics
    totalFoodDonated: 'Food Rescued',
    donations: 'Donations',
    costSavings: 'Cost Saved',
    emissionReduction: 'Emission Reduction',
    // Navigation
    profile: 'Profile',
    logout: 'Logout',
    giveFeedback: 'Give feedback',
    activities: 'Activities',
    routes: 'Routes',
    help: 'Help',
    crm: 'CRM',
    messages: 'Messages',
    // Success confirmations
    claimConfirmed: 'Claim Confirmed!',
    claimConfirmedDescription: 'Your claim has been successfully confirmed.',
    deliveryConfirmed: 'Delivery Confirmed!',
    deliveryConfirmedDescription: 'Your delivery has been successfully confirmed.',
    // Food donation
    donate: 'Create listing',
    createDonation: 'Create new listing',
    donationCreated: 'Listing created successfully!',
    nameOfFood: 'Name of food',
    foodCategory: 'Food category',
    quantity: 'Quantity',
    description: 'Description',
    address: 'Address',
    // Food categories
    selectCategory: 'Select category',
    categoryMainProtein: 'Main protein (stew, sauce, etc.)',
    categoryEnergySupplement: 'Energy supplement (e.g. rice)',
    categorySoup: 'Soup',
    categorySaladIngredients: 'Salad ingredients',
    categoryOther: 'Other',
    // Auth
    email: 'Email',
    password: 'Password',
    login: 'Login',
    register: 'Register',
    signIn: 'Sign in',
    signUp: 'Sign up',
    welcomeBack: 'Welcome back',
    signInToAccount: 'Sign in to your account',
    emailAddress: 'Email address',
    dontHaveAccount: "Don't have an account?",
    forgotPassword: 'Forgot your password?',
    rememberMe: 'Remember me',
    signingIn: 'Signing in...',
    invalidEmailPassword: 'Invalid email or password',
    networkError: 'Network error. Please try again.',
    resetPasswordDesc: 'Enter your email to receive a reset link',
    sendResetLink: 'Send Reset Link',
    sendingResetLink: 'Sending...',
    backToLogin: 'Back to Login',
    checkEmail: 'Check your email for reset instructions',
    resetPassword: 'Reset Password',
    newPassword: 'New Password',
    confirmPassword: 'Confirm Password',
    confirmNewPassword: 'Confirm New Password',
    updatePassword: 'Update Password',
    updatingPassword: 'Updating...',
    passwordUpdated: 'Password updated successfully',
    passwordsDoNotMatch: 'Passwords do not match',
    passwordTooShort: 'Password must be at least 6 characters',
    createAccount: 'Create Account',
    creatingAccount: 'Creating Account...',
    alreadyHaveAccount: 'Already have an account?',
    // Forms
    required: 'Required',
    optional: 'Optional',
    fieldRequired: 'This field is required',
    // Errors
    error: 'Error',
    somethingWentWrong: 'Something went wrong',
    // Dashboard specific (adapted from Ninja's impact updates)
    yourImpact: 'Your actions are making a difference! This is the impact of your latest activity:',
    peopleServed: 'People Served',
    foodRequested: 'Food Requested',
    activeRequests: 'Active Requests',
    fulfilledRequests: 'Fulfilled Requests',
    exportImpactReport: 'Check out more impact data',
    requestHistoryAndImpactData: 'Access more data on your social and environmental impact for reporting and planning',
    date: 'Date',
    sortBy: 'Sort by',
    sortByDate: 'Date (newest first)',
    sortByItemName: 'Item name (A–Z)',
    sortByOrganization: 'Organization (A–Z)',
    sortByQuantity: 'Quantity (high → low)',
    allTypes: 'All Types',
    requests: 'Requests',
    exportToPdf: 'Export to PDF',
    environmentalAndSocialImpactData: 'Data on your financial, social and environmental impact helps with reporting, communicating and operation planning.',
    // Impact metrics (receiver adapted from Ninja's donor updates)
    peopleServedDesc: 'People received proper meals through your requests',
    foodRequestedDesc: 'Total weight of food requested in your latest request',
    activeRequestsDesc: 'Requests currently being matched with donors',
    fulfilledRequestsDesc: 'Requests successfully completed with food delivered',
    totalFoodOffered: 'Total weight of food in your latest food listing',
    portionsOffered: 'People got a proper meal (500g/portion)',
    savedInFoodDisposalCosts: 'Saved in production & disposal costs (average)',
    co2Avoided: "Trees' worth of CO₂ saved",
    editFoodItem: 'Edit Food Item',
    addFoodItem: 'Add Food Item',
    addPhotoDescription: 'Add Photo & Description',
    changesSaved: 'Changes Saved',
    pickupSlot: 'Pickup Slot',
    pickup: 'Pickup',
    selectDate: 'Select Date',
    dateFormatPlaceholder: 'DD/MM/YYYY',
    dateFormat: 'dd/MM/yyyy',
    selectTime: 'Select Time',
    startTime: 'Start Time',
    endTime: 'End Time',
    addSlot: 'Add Slot',
    editSlot: 'Edit Slot',
    deleteSlot: 'Delete Slot',
    schedule: 'Schedule',
    recurring: 'Recurring',
    dateNotSet: 'Date not set',
    timeNotSet: 'Time not set',
    noSlotsAdded: 'No slots added',
    addFirstSlot: 'Add your first pickup slot',
    summary: 'Summary',
    thankYou: 'Thank You',
    donationComplete: 'Donation Complete',
    success: 'Success',
    close: 'Close',
    confirm: 'Confirm',
    yes: 'Yes',
    no: 'No',
    addAnotherPickupSlot: 'Add Another Pickup Slot',
    addAnotherDeliverySlot: 'Add Another Delivery Slot',
    next: 'Next',
    previous: 'Previous',
    done: 'Done',
    finish: 'Finish',
    step: 'Step',
    of: 'of',
    noDonationsFound: 'No donations found',
    noRequestsFound: 'No requests found',
    search: 'Search',
    filter: 'Filter',
    all: 'All',
    active: 'Active',
    completed: 'Completed',
    view: 'View',
    details: 'Details',
    requestDetails: 'Details',
    englishLabel: 'English',
    finnishLabel: 'Finnish',
    createListing: 'Create listing',
    recurringDonation: 'Recurring Donation',
    english: 'English',
    finnish: 'Finnish',
    activity: 'Your active items',
    yourActiveItems: 'Your active items',
    activeDonations: 'Active listings',
    activeOffers: 'Active offers',
    impactSummary: 'Impact summary',
    fullName: "Contact person's name",
    fullNameLabel: "Contact person's name",
    organizationName: 'Organization Name',
    organizationNameLabel: 'Organization Name',
    contactNumber: 'Contact Number',
    instructionsForDriver: 'Instructions for driver',
    defaultDriverInstructions: 'Default Driver Instructions',
    notSet: 'Not set',
    role: 'Account type',
    foodDonor: 'Food Donor',
    foodReceiver: 'Food Receiver',
    terminalOperator: 'Terminal Operator',
    city: 'City Administrator',
    iAmA: 'I am a',
    editProfile: 'Edit Profile',
    saveChanges: 'Save Changes',
    cancelChanges: 'Cancel',
    // Pickup slot specific
    addPickupSlotButton: 'Add pickup slot',
    addDeliverySlotButton: 'Add delivery slot',
    dateLabel: 'Date',
    startTimeLabel: 'Start time',
    endTimeLabel: 'End time',
    // Request flow specific
    selectRequestType: 'Select Request Type',
    oneTimeRequest: 'One-time Request',
    recurringRequest: 'Recurring Request',
    requestType: 'Request Type',
    requestSchedule: 'Request Schedule',
    requestSummary: 'Request Summary',
    deliveryDetails: 'Delivery Details',
    requestSubmitted: 'Request submitted',
    requestSubmittedDesc: 'Request received successfully, thank you!',
    requestPeriod: 'Request Period',
    pickupSchedule: 'Pickup schedule',
    deliverySchedule: 'Delivery schedule',
    driverInstructions: 'Instructions for driver',
    updateAddressInProfile: 'Also update this address in my profile for the future',
    updateInstructionsInProfile: 'Also update these instructions in my profile as default',
    enterYourFullAddress: 'Enter your full address',
    pleaseRingTheDoorbell: 'e.g. Please ring the doorbell',
    portions: 'Portions',
    allergiesIntolerancesDiets: 'Allergies, intolerances & diets',
    submitRequest: 'Submit Request',
    continuing: 'Submitting...',
    addAddress: 'Add Address',
    backToDashboard: 'Back to Dashboard',
    peopleCount: 'Number of people',
    enterNumberOfPeople: 'Enter quantity',
    deliveryDate: 'Delivery date',
    deliveryTimeslot: 'Delivery timeslot',
    selectAllergens: 'Select allergens',
    describeFood: 'Request description',
    foodDescriptionPlaceholder: 'Enter text here.',
    scheduleType: 'Schedule Type',
    configuredSchedules: 'Configured Schedules',
    addAnotherSchedule: 'Add Another Schedule',
    configureSchedule: 'Configure Schedule',
    startDate: 'Start Date',
    endDate: 'End Date',
    selectDays: 'Select days of the week',
    timeRangeForSelectedDays: 'Available Time Range for Selected Days',
    // Pickup scheduling (from Ninja's updates)
    schedulePickup: 'Schedule Pickup',
    addPickupSlot: 'Add pickup slot',
    editPickupSlot: 'Edit pickup slot',
    deletePickupSlot: 'Delete pickup slot',
    addDeliverySlot: 'Add delivery slot',
    editDeliverySlot: 'Edit delivery slot',
    deleteDeliverySlot: 'Delete delivery slot',
    availableTimeRange: 'Available Time Range',
    oneTime: 'One-time',
    recurringInterval: 'Recurring interval',
    daily: 'Daily',
    weekly: 'Weekly',
    monthly: 'Monthly',
    custom: 'Custom...',
    recurringSchedule: 'Recurring schedule',
    doesNotRepeat: 'Does not repeat',
    repeatEvery: 'Repeat every',
    day: 'day',
    days: 'days',
    week: 'week',
    weeks: 'weeks',
    every: 'Every',
    times: 'times',
    ends: 'Ends',
    never: 'Never',
    on: 'On',
    after: 'After',
    occurrences: 'occurrences',
    customRecurrence: 'Custom recurrence',
    recurrencePattern: 'Recurrence pattern',
    selectDaysOfWeek: 'Select days of the week',
    selectedDay: 'Selected day',
    selectedDays: 'selected days',
    pickupDateMustBeWithinRange: 'Pickup date must be within the request date range.',
    sunday: 'Sunday',
    monday: 'Monday',
    tuesday: 'Tuesday',
    wednesday: 'Wednesday',
    thursday: 'Thursday',
    friday: 'Friday',
    saturday: 'Saturday',
    // Allergens (from Ninja's updates)
    allergens: 'Allergens',
    qtyLabel: 'Qty',
    descriptionLabel: 'Description',
    allergiesIntolerances: 'Allergies, intolerances & diets',
    selectDietaryRestrictions: 'Select dietary restrictions...',
    // Success page specific (from Ninja's updates)
    nextSteps: 'Next Steps',
    requestAddedToSystem: 'Request received successfully, thank you!',
    matchingInProgress: 'Matching in Progress',
    lookingForMatches: "We're looking for requests that match your criteria.",
    getNotified: 'Get Notified',
    receiveNotificationWhenMatch: "You'll receive a notification when there's a match to confirm pickup.",
    // Common words
    available: 'Available',
    claimed: 'Claimed',
    cancelled: 'Cancelled',
    from: 'from',
    until: 'Until',
    today: 'Today',
    tomorrow: 'Tomorrow',
    request: 'Request',
    // Manual donation form specific
    quantityKg: 'Quantity (kg)',
    enterFoodName: 'Enter food name',
    enterQuantity: 'Enter quantity',
    currentItemsInDonation: 'Current Items in Donation',
    addAnotherItem: 'Add Another Item',
    goBackToDashboard: 'Go Back to Dashboard',
    photosHelpIdentify: 'Photos help identify your food donation',
    addPhotos: 'Add photos',
    addMore: 'Add more',
    uploading: 'Uploading...',
    maxSizeMb: 'Max 5MB each',
    photosCount: 'photos',
    imageUploadError: 'Image size too big. Please select an image under 5MB.',
    maxImagesError: 'You can only upload up to {maxImages} images.',
    invalidFileTypeError: 'Please select JPEG, PNG, or WebP image files only.',
    enterDescription: 'Enter description',
    savingEllipsis: 'Saving...',
    addItem: 'Continue',
    // Recurring donation form specific
    approximateQuantityKg: 'Approximate quantity (kg)',
    pleaseDescribeFood: 'Please describe the food you want to donate',
    foodDescriptionPlaceholderLong: 'e.g., Fresh vegetables, prepared meals, dairy products...',
    quantityRequired: 'Quantity is required',
    quantityMinimum: 'Quantity must be at least 1',
    enterValidNumber: 'Please enter a valid number',
    allergensAndDietaryInfo: 'Allergens & dietary information',
    gettingStarted: 'Getting Started',
    architecture: 'Architecture',
    development: 'Development',
    deployment: 'Deployment',
    apiReference: 'API Reference',
    decisions: 'Decisions',
    // Allergens options
    notSpecified: 'Not specified',
    glutenFree: 'Gluten-free',
    lactoseFree: 'Lactose-free',
    milkFree: 'Milk-free',
    lowLactose: 'Low-lactose',
    eggFree: 'Egg-free',
    soyFree: 'Soy-free',
    noPeanuts: 'Contains peanuts',
    noOtherNuts: 'Contains other nuts',
    noFish: 'Contains fish',
    noCrustaceans: 'Contains crustaceans',
    noCelery: 'Contains celery',
    noMustard: 'Contains mustard',
    noSesamSeeds: 'Contains sesame seeds',
    noSulphurDioxide: 'Contains sulphur dioxide / sulphites >10 mg/kg or litre',
    noLupin: 'Contains lupin',
    noMolluscs: 'Contains molluscs',
    // Request details page
    confirmForToday: 'Confirm for today',
    orderCompleted: 'Order completed',
    confirmed: 'Confirmed',
    seeAllRequests: 'See all requests',
    showMore: 'Show more',
    showLess: 'Show less',
    // Navigation & UI (New additions)
    zipli: 'Zipli',
    whatWouldYouLikeToDo: 'What would you like to do?',
    donateOrSell: 'Donate or Sell',
    offerFoodItems: 'Offer food items to others.',
    createRequestForItems: 'Create a request for specific items.',
    returnToHome: 'Return to Home',
    apply: 'Apply',
    // Dashboard Titles (New additions)
    foodDonorDashboard: 'Food Donor Dashboard',
    welcomeDonorDashboard: 'Welcome to your donor dashboard',
    foodReceiverDashboard: 'Food Receiver Dashboard',
    cityDashboard: 'City Dashboard',
    terminalDashboard: 'Food Terminal Dashboard',
    welcomeTerminalDashboard: 'Welcome to your terminal dashboard. Here you will be able to:',
    // Dashboard Actions (New additions)
    listAvailableFood: 'List available food',
    createNewDonations: 'Create new donations',
    trackDonationStatus: 'Track donation status',
    managePickupSchedules: 'Manage pickup schedules',
    processLargeScaleDonations: 'Process large-scale food donations',
    coordinateWithMultiple: 'Coordinate with multiple donors and receivers',
    manageFoodStorage: 'Manage food storage and distribution',
    trackProcessingCapacity: 'Track processing center capacity',
    // Form Labels & Placeholders (New additions)
    eg10: 'e.g. 10',
    ringDoorbell: 'Please ring the doorbell',
    searchRequests: 'Search requests...',
    enter6DigitCode: 'Enter 6-digit code',
    enterNewPassword: 'Enter new password',
    // Status & Messages (New additions)
    noRequestDataFound: 'No request data found',
    qrCodeUnavailable: 'QR code unavailable',
    notEnoughDataPoints: 'Not enough data points for a line chart',
    didntReceiveCode: "Didn't receive the code?",
    uploadedPreview: 'Uploaded preview',
    placeholderImage: 'Placeholder image',
    noImage: 'No Image',
    errorLoadingImage: 'Error loading image',
    // Dialog Titles (New additions)
    cancelRequest: 'Cancel Request',
    confirmDelivery: 'Confirm Delivery',
    areYouSure: 'Are you sure?',
    confirmClaim: 'Confirm Claim',
    removeListing: 'Remove Listing',
    yesRemove: 'Yes, Remove',
    removing: 'Removing...',
    removeListingDescription: 'This will permanently remove the listing from public view. This action cannot be undone.',
    confirmClaimDescription: 'Please confirm that this donation has been claimed and received.',
    confirmClaimClause: 'I confirm that this donation has been claimed and received in good condition. I understand that by confirming this claim, I acknowledge that the donation will be marked as claimed and removed from public listings.',
    confirmDeliveryDescription: 'Please confirm that the food has been successfully delivered and received.',
    confirmDeliveryClause: 'I confirm that the food has been delivered and received in good condition. I understand that by confirming this delivery, I acknowledge that the transaction is complete and the request will be marked as fulfilled.',
    editRequestPeriod: 'Edit request period',
    editSchedule: 'Edit schedule',
    editDeliveryTime: 'Edit delivery time',
    deleteSchedule: 'Delete schedule',
    donationSummary: 'Donation Summary',
    donationItems: 'Donation Items',
    addressAndInstructions: 'Address & Instructions',
    saveAddressToProfile: 'Save this address to my profile',
    saveInstructionsToProfile: 'Save these instructions to my profile',
    editPickupTime: 'Edit pickup time',
    confirmPickup: 'Confirm pickup',
    rememberToMarkPickedUp: 'Remember to mark food as picked up by clicking the donation name in the green window on the front page',
    // Photo upload options
    photoOptions: 'Photo Options',
    takePhoto: 'Take Photo',
    chooseFromGallery: 'Choose from Gallery',
    cameraNotAvailable: 'Camera not available',
    tapToTakePhotoOrChoose: 'Tap to take photo or choose file',
    tapToChooseFile: 'Tap to choose file',
    dragDropOrClick: 'Drag & drop or click to choose files',
    supportedFormats: 'Supported formats: JPG, PNG, WebP',
    maxFileSize: 'Max',
    // User Roles (New additions - some already exist, adding missing ones)
    cityOfficial: 'City Official',
    // Admin (New additions)
    users: 'Users',
    totalUsers: 'Total Users',
    qrLogin: 'QR Login',
    // Additional form placeholders and labels
    addressPlaceholder: 'Enter your full address',
    contactNumberPlaceholder: 'ContactNumber',
    emailAddressPlaceholder: 'Your email',
    passwordPlaceholder: 'Your password',
    // Additional status messages
    allTime: 'All Time',
    last30Days: 'Last 30 Days',
    last3Months: 'Last 3 Months',
    lastYear: 'Last Year',
    // Organization names (for reference, might not need translation)
    tsanssi: 'Tsänssi',
    redCross: 'Red Cross',
    andreasChurch: 'Andreas Church',
    helsinkiFoodTerminal: 'Helsinki Food Terminal',
    // Additional UI text (fixing cross-language issues)
    chooseRequestType: 'Choose the type that best fits your needs',
    note: 'Note',
    multipleRequestsNote: 'You can create multiple requests based on your needs. Each request will be matched with available donations.',
    noActiveDonationsOrRequests: "You don't have any active donations or requests",
    // New keys for fixing malformed text
    editRequest: 'Edit Request',
    contactRequester: 'Contact Requester',
    viewAll: 'View All',
    by: 'by',
    searchDonations: 'Search donations...',
    noDonationsAvailable: 'No donations available at this time',
    // Additional keys for thank-you and pickup-slot pages
    donationCreatedDesc: '',
    changesSavedDesc: 'Your changes have been saved successfully.',
    addDeliveryTimeSlots: 'Add one or more delivery time slots to give donors flexibility.',
    // Terminal Dashboard specific
    operationsOverview: 'Operations Overview',
    currentStatusAndMetrics: 'Current status and real-time metrics',
    volumeProcessed: 'Volume Processed',
    storageUtilization: 'Storage Utilization',
    processingEfficiency: 'Processing Efficiency',
    activeRoutes: 'Active Routes',
    totalKilos: 'Total kilos processed',
    activeOrganizations: 'Active organizations',
    estimatedCO2: 'Estimated CO₂ saved',
    upcoming: 'Upcoming',
    nextPickupsDeliveries: 'Next pickups and deliveries',
    noUpcomingItems: 'No upcoming items.',
    terminalOverviewSubtitle: 'Quick overview for the terminal.',
    incomingDonations: 'Incoming Donations',
    deliveryRequests: 'Delivery Requests',
    searchOrganizations: 'Search organizations, food items, descriptions...',
    allStatus: 'All Status',
    received: 'Received',
    processing: 'Processing',
    dispatched: 'Dispatched',
    fulfilled: 'Fulfilled',
    exportData: 'Export Data',
    donationProcessingDetails: 'Donation Processing Details',
    deliveryRequestDetails: 'Delivery Request Details',
    noDonationsMatchFilters: 'No donations match your filters',
    noRequestsMatchFilters: 'No requests match your filters',
    organization: 'Organization',
    processingStatus: 'Processing Status',
    foodItems: 'Food Items',
    routeId: 'Route ID',
    location: 'Location',
    pickupDate: 'Pickup Date',
    pickupTime: 'Pickup Time',
    status: 'Status',
    urgency: 'Urgency',
    terminalPeopleCount: 'People Count',
    deliveryWindow: 'Delivery Window',
    assignedRoute: 'Assigned Route',
    items: 'items',
    people: 'people',
    low: 'Low',
    medium: 'Medium',
    high: 'High'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/translations/fi.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Finnish translations - static file
// Updated manually as needed
__turbopack_context__.s([
    "fi",
    ()=>fi
]);
const fi = {
    // Common actions
    add: 'Lisää',
    back: 'Takaisin',
    cancel: 'Peruuta',
    continue: 'Jatka',
    delete: 'Poista',
    edit: 'Muokkaa',
    save: 'Tallenna',
    submit: 'Lähetä',
    loading: 'Ladataan...',
    // Dashboard
    dashboard: 'Kotinäkymä',
    impact: 'Vaikuttavuus',
    analytics: 'Analytiikka',
    overview: 'Yhteenveto',
    donation: 'Ilmoitus',
    submitting: 'Lähetetään...',
    addDonation: 'Lisää lahjoitus',
    explore: 'Tutki',
    requestFood: 'Pyydä ruokaa',
    terminal: 'Terminaali',
    createRequest: 'Luo pyynto',
    createSingleRequest: 'Luo yksittäinen pyynto välittömiin tarpeisiin',
    setupRepeatingSchedule: 'Aseta toistuva aikataulu jatkuviin tarpeisiin',
    goodToSeeYou: 'Moi! Tehdään yhdessä hävikistä hyvikkiä.',
    // Impact metrics
    totalFoodDonated: 'Ruokaa Pelastettu',
    donations: 'Lahjoitukset',
    costSavings: 'Säästöt',
    emissionReduction: 'Päästövähennys',
    // Navigation
    profile: 'Profiili',
    logout: 'Kirjaudu ulos',
    giveFeedback: 'Anna palautetta',
    matching: 'Kohtaanto',
    routes: 'Reitit',
    help: 'Ohjeet',
    crm: 'CRM',
    messages: 'Viesti',
    // Success confirmations
    claimConfirmed: 'Varauksesi vahvistettu!',
    claimConfirmedDescription: 'Varauksesi on vahvistettu onnistuneesti.',
    deliveryConfirmed: 'Toimitus vahvistettu!',
    deliveryConfirmedDescription: 'Toimituksesi on vahvistettu onnistuneesti.',
    // Food donation
    donate: 'Luo ilmoitus',
    createDonation: 'Luo uusi ilmoitus',
    donationCreated: 'Ilmoitus luotu onnistuneesti!',
    nameOfFood: 'Ruoan nimi',
    foodCategory: 'Ruokakategoria',
    quantity: 'Määrä',
    description: 'Kuvaus',
    address: 'Osoite',
    // Food categories
    selectCategory: 'Valitse kategoria',
    categoryMainProtein: 'Pääproteiini (muhennos, kastike, tms.)',
    categoryEnergySupplement: 'Energialisäke (esim. riisi)',
    categorySoup: 'Keitto',
    categorySaladIngredients: 'Salaattiainekset',
    categoryOther: 'Muu',
    // Auth
    email: 'Sähköposti',
    password: 'Salasana',
    login: 'Kirjaudu sisään',
    register: 'Rekisteröidy',
    signIn: 'Kirjaudu sisään',
    signUp: 'Rekisteröidy',
    welcomeBack: 'Tervetuloa takaisin',
    signInToAccount: 'Kirjaudu tilillesi',
    emailAddress: 'Sähköpostiosoite',
    dontHaveAccount: 'Eikö sinulla ole tiliä?',
    forgotPassword: 'Unohditko salasanan?',
    rememberMe: 'Muista minut',
    signingIn: 'Kirjaudutaan sisään...',
    invalidEmailPassword: 'Virheellinen sähköposti tai salasana',
    networkError: 'Verkkovirhe. Yritä uudelleen.',
    resetPasswordDesc: 'Syötä sähköpostiosoitteesi saadaksesi nollauslinkki',
    sendResetLink: 'Lähetä nollauslinkki',
    sendingResetLink: 'Lähetetään...',
    backToLogin: 'Takaisin kirjautumiseen',
    checkEmail: 'Tarkista sähköpostisi nollausohjeita varten',
    resetPassword: 'Nollaa salasana',
    newPassword: 'Uusi salasana',
    confirmPassword: 'Vahvista salasana',
    confirmNewPassword: 'Vahvista uusi salasana',
    updatePassword: 'Päivitä salasana',
    updatingPassword: 'Päivitetään...',
    passwordUpdated: 'Salasana päivitetty onnistuneesti',
    passwordsDoNotMatch: 'Salasanat eivät täsmää',
    passwordTooShort: 'Salasanan tulee olla vähintään 6 merkkiä',
    createAccount: 'Luo tili',
    creatingAccount: 'Luodaan tiliä...',
    alreadyHaveAccount: 'Onko sinulla jo tili?',
    // Forms
    required: 'Pakollinen',
    optional: 'valinnainen',
    addPhoto: 'Lisää kuva',
    fieldRequired: 'Tämä kenttä on pakollinen',
    // Errors
    error: 'Virhe',
    somethingWentWrong: 'Jotakin meni vikaan',
    imageUploadError: 'Kuvan koko on liian suuri. Valitse kuva alle 5MB.',
    maxImagesError: 'Voit ladata enintään {maxImages} kuvaa.',
    invalidFileTypeError: 'Valitse vain JPEG, PNG tai WebP kuvatiedostoja.',
    // Dashboard specific (adapted from Ninja's impact updates)
    yourImpact: 'Teoillasi on aitoa merkitystä! Tässä viimeisimmän toimintasi vaikuttavuus:',
    peopleServed: 'Palveltuja ihmisiä',
    foodRequested: 'Pyydetty ruoka',
    activeRequests: 'Aktiiviset pyynnöt',
    fulfilledRequests: 'Täytetyt pyynnöt',
    exportImpactReport: 'Täältä näet lisää vaikuttavuusdataa',
    requestHistoryAndImpactData: 'Siirry tarkastelemaan lisää sosiaalisen ja ympäristövaikutuksen dataa raportointia ja suunnittelua varten',
    date: 'Noutopäivä',
    sortBy: 'Järjestä',
    sortByDate: 'Päivä (uusin ensin)',
    sortByItemName: 'Tuotenimi (A–Ö)',
    sortByOrganization: 'Organisaatio (A–Ö)',
    sortByQuantity: 'Määrä (suurin → pienin)',
    allTypes: 'Kaikki tyypit',
    requests: 'Pyynnöt',
    exportToPdf: 'Vie PDF:ksi',
    environmentalAndSocialImpactData: 'Keräämämme vaikuttavuusdata auttaa raportoimaan, viestimään ja suunnittelemaan toimintaa entistä paremmin.',
    // Impact metrics (receiver adapted from Ninja's donor updates)
    peopleServedDesc: 'Ihmistä sai kunnon aterian pyynnösten kautta',
    foodRequestedDesc: 'Viimeisimmän pyyntösi yhteenlaskettu kilomäärä',
    activeRequestsDesc: 'Pyynnöt etsivät parhaillaan lahjoittajia',
    fulfilledRequestsDesc: 'Pyynnöt täytettiin onnistuneesti ruoan toimituksella',
    totalFoodOffered: 'Viimeisimmän ilmoituksesi yhteenlaskettu kilomäärä',
    portionsOffered: 'Ihmistä sai kunnon aterian (500g/annos)',
    savedInFoodDisposalCosts: 'Säästetty tuotanto- ja jätekustannuksissa (keskiarvo)',
    co2Avoided: 'Puun verran hiilidioksidipäästöjä vältetty',
    editFoodItem: 'Muokkaa ruoka-ainetta',
    addFoodItem: 'Lisää ruoka-aineita',
    addPhotoDescription: 'Lisää kuva ja kuvaus',
    changesSaved: 'Muutokset tallennettu',
    pickupSlot: 'Noutovuoro',
    pickup: 'Nouto',
    selectDate: 'Valitse päivä',
    dateFormatPlaceholder: 'pp.kk.vvvv',
    dateFormat: 'dd.MM.yyyy',
    selectTime: 'Valitse aika',
    startTime: 'Alkuaika',
    endTime: 'Loppuaika',
    addSlot: 'Lisää vuoro',
    editSlot: 'Muokkaa vuoroa',
    deleteSlot: 'Poista vuoro',
    schedule: 'Aikataulu',
    recurring: 'Toistuva',
    dateNotSet: 'Päivämäärää ei ole asetettu',
    timeNotSet: 'Aika ei asetettu',
    noSlotsAdded: 'Vuoroja ei lisätty',
    addFirstSlot: 'Lisää ensimmäinen noutovuorosi',
    summary: 'Yhteenveto',
    thankYou: 'Kiitos',
    donationComplete: 'Lahjoitus valmis',
    success: 'Onnistui',
    close: 'Sulje',
    confirm: 'Vahvista',
    yes: 'Kyllä',
    no: 'Ei',
    addAnotherPickupSlot: 'Lisää toinen noutovuoro',
    addAnotherDeliverySlot: 'Lisää toinen toimitusaika',
    next: 'Seuraava',
    previous: 'Edellinen',
    done: 'Valmis',
    finish: 'Viimeistele',
    step: 'Vaihe',
    of: '/',
    noDonationsFound: 'Lahjoituksia ei löytynyt',
    noRequestsFound: 'Pyyntöjä ei löytynyt',
    search: 'Haku',
    filter: 'Suodatin',
    all: 'Kaikki',
    active: 'Aktiivinen',
    completed: 'Valmis',
    view: 'Näytä',
    details: 'Lisätiedot',
    requestDetails: 'Lisätiedot',
    englishLabel: 'English',
    finnishLabel: 'Suomi',
    createListing: 'Luo ilmoitus',
    createListingFoodItem: 'Luo ilmoitus foodItem',
    luoIlmoitusFoodItem: 'Luo ilmoitus foodItem',
    recurringDonation: 'Toistuva lahjoitus',
    english: 'English',
    finnish: 'Suomi',
    activity: 'Aktiiviset tapahtumasi',
    yourActiveItems: 'Aktiiviset tapahtumasi',
    activeDonations: 'Aktiiviset ilmoitukset',
    activeOffers: 'Aktiiviset tarjoukset',
    impactSummary: 'Yhteenveto vaikuttavuudesta',
    fullName: 'Koko nimi',
    fullNameLabel: 'Koko nimi',
    organizationName: 'Organisaation nimi',
    organizationNameLabel: 'Organisaation nimi',
    contactNumber: 'Puhelinnumero',
    instructionsForDriver: 'Ohjeita kuljettajalle',
    defaultDriverInstructions: 'Ohjeita kuljettajalle',
    notSet: 'Ei asetettu',
    role: 'Rooli',
    foodDonor: 'Ruoan lahjoittaja',
    foodReceiver: 'Ruoan vastaanottaja',
    terminalOperator: 'Terminaalin käyttäjä',
    city: 'Kaupungin ylläpitäjä',
    iAmA: 'Olen',
    editProfile: 'Muokkaa profiilia',
    saveChanges: 'Tallenna muutokset',
    cancelChanges: 'Peruuta',
    // Pickup slot specific
    addPickupSlotButton: 'Lisää noutovuoro',
    addDeliverySlotButton: 'Lisää toimitusaika',
    dateLabel: 'Päivämäärä',
    startTimeLabel: 'Alkuaika',
    endTimeLabel: 'Loppuaika',
    // Request flow specific
    selectRequestType: 'Valitse pyyntötyyppi',
    oneTimeRequest: 'Kertaluonteinen pyyntö',
    recurringRequest: 'Toistuva pyyntö',
    requestType: 'Pyyntötyyppi',
    requestSchedule: 'Pyynnön aikataulu',
    requestSummary: 'Pyynnön yhteenveto',
    deliveryDetails: 'Toimitusten tiedot',
    requestSubmitted: 'Ilmoitus lähetetty',
    requestSubmittedDesc: 'Kiitos, ilmoituksesi on otettu vastaan!',
    requestPeriod: 'Pyynnön jakso',
    pickupSchedule: 'Noutoajankohta',
    deliverySchedule: 'Toimitusaikataulu',
    driverInstructions: 'Ohjeet kuljettajalle',
    updateAddressInProfile: 'Päivitä tämä osoite myös profiiliini myöhempää käyttöä varten',
    updateInstructionsInProfile: 'Päivitä nämä ohjeet profiiliini myöhempää käyttöä varten.',
    enterYourFullAddress: 'Syötä koko osoitteesi',
    pleaseRingTheDoorbell: 'esim. Ole hyvä ja soita ovikelloa',
    portions: 'Annosta',
    allergiesIntolerancesDiets: 'Allergiat, intoleranssit ja ruokarajoitteet',
    submitRequest: 'Lähetä pyyntö',
    continuing: 'Lähetetään...',
    addAddress: 'Lisää osoite',
    backToDashboard: 'Takaisin kotinäkymään',
    peopleCount: 'Henkilömäärä',
    enterNumberOfPeople: 'Syötä määrä',
    deliveryDate: 'Toimituksen päivämäärä',
    deliveryTimeslot: 'Toimituksen aikaväli',
    selectAllergens: 'Valitse allergeenit',
    describeFood: 'Pyynnön kuvaus',
    foodDescriptionPlaceholder: 'Lisää tähän vihjetekstiä.',
    scheduleType: 'Aikataulun tyyppi',
    configuredSchedules: 'Määritetyt aikataulut',
    addAnotherSchedule: 'Lisää toinen aikataulu',
    configureSchedule: 'Määritä aikataulu',
    startDate: 'Alkupäivä',
    endDate: 'Loppupäivä',
    selectDays: 'Valitse viikonpäivät',
    timeRangeForSelectedDays: 'Valittavissa oleva aikaikkuna valituille päiville',
    // Pickup scheduling
    schedulePickup: 'Aseta noutoajankohta',
    addPickupSlot: 'Lisää noutoajankohta',
    editPickupSlot: 'Muokkaa noutoajankohtaa',
    deletePickupSlot: 'Poista noutoajankohta',
    addDeliverySlot: 'Lisää toimitusaika',
    editDeliverySlot: 'Muokkaa toimitusaikaa',
    deleteDeliverySlot: 'Poista toimitusaika',
    availableTimeRange: 'Valittavissa oleva aikaikkuna',
    oneTime: 'Kertaluonteinen',
    recurringInterval: 'Toistuva tapahtumasarja',
    daily: 'Päivittäinen',
    weekly: 'Viikottainen',
    monthly: 'Kuukausittainen',
    custom: 'Räätälöi...',
    recurringSchedule: 'Toistuva aikataulu',
    doesNotRepeat: 'Ei toistu',
    repeatEvery: 'Toista joka',
    day: 'päivä',
    days: 'päivää',
    week: 'viikko',
    weeks: 'viikkoa',
    every: 'Joka',
    times: 'kertaa',
    ends: 'Päättyy',
    never: 'EI koskaan',
    on: 'Päivänä',
    after: 'jälkeen',
    occurrences: 'kertaa',
    customRecurrence: 'Muokkaa toistuvuutta',
    recurrencePattern: 'Toistuva aikataulu',
    selectDaysOfWeek: 'Valitse viikonpäivät',
    selectedDay: 'Valittu päivä',
    selectedDays: 'valitut päivät',
    pickupDateMustBeWithinRange: 'Noutopäivän täytyy olla pyynnössä määritellyn aikaikkunan sisällä.',
    sunday: 'Sunnuntai',
    monday: 'Maanantai',
    tuesday: 'Tiistai',
    wednesday: 'Keskiviikko',
    thursday: 'Torstai',
    friday: 'Perjantai',
    saturday: 'Lauantai',
    // Allergens
    allergens: 'Allergeenit',
    qtyLabel: 'Määrä',
    descriptionLabel: 'Kuvaus',
    allergiesIntolerances: 'Allergiat, intoleranssit ja ruokarajoitteet',
    selectDietaryRestrictions: 'Valitse ruokarajoitteet',
    // Success page specific
    nextSteps: 'Seuraavat vaiheet',
    requestAddedToSystem: 'Kiitos, ilmoituksesi on otettu vastaan!',
    matchingInProgress: 'Yhteensovitus käynnissä',
    lookingForMatches: 'Etsimme pyyntöjä, jotka vastaavat kriteerejäsi.',
    getNotified: 'Saat ilmoituksen',
    receiveNotificationWhenMatch: 'Saat notifikaation, kun löydämme sopivan vastaanottajan ja voimme varmistaa noutoajan.',
    // Impact page specific
    yourCompleteImpact: 'Kokonaisvaikutuksesi',
    allTime: 'Koko aika',
    last30Days: 'Viimeiset 30 päivää',
    last3Months: 'Viimeiset 3 kuukautta',
    lastYear: 'Viimeinen vuosi',
    portionsCreated: 'Luodut annokset',
    historicalTrends: 'Trendit',
    donationTrend: 'Lahjoitustrendi',
    lastSixMonths: '(Viimeiset 6 kuukautta)',
    environmentalImpactTrend: 'Ympäristövaikutus trendi',
    co2Reduction: 'CO2 vähennys',
    successRate: 'Onnistumisprosentti',
    avgPerDonation: 'Keskiarvo/lahjoitus',
    avgPickupTime: 'Keskim. noutoaika',
    downloadCompleteReport: 'Lataa täydellinen vaikutusraportti ja analytiikka',
    detailedAnalytics: 'Yksityiskohtainen analytiikka',
    peopleHelped: 'Autettuja ihmisiä',
    totalDonations: 'Lahjoituksia yhteensä',
    activityBreakdown: 'Toiminnan erittely',
    performanceMetrics: 'Suorituskykymittarit',
    monthsActive: 'Kuukautta aktiivisena',
    impactSummaryTitle: 'Vaikutusraportti',
    environmentalImpact: 'Ympäristövaikutus',
    economicImpact: 'Taloudelliset vaikutukset',
    // Contact page
    contact: 'Yhteystiedot',
    getInTouch: 'Ota yhteyttä',
    phone: 'Puhelin',
    businessHours: 'Aukioloajat',
    needHelp: 'Tarvitsetko apua?',
    emergencySupport: 'Hätätuki',
    forUrgentFoodSafetyIssues: 'Kiireellisissä ruokaturvallisuusasioissa:',
    available247: 'Saatavilla 24/7',
    ourSupportTeam: 'Tukitiimimme on täällä auttamassa sinua kaikissa Ziplin käyttöön liittyvissä kysymyksissä.',
    reducingFoodWaste: 'Vähennämme ruokahävikkiä ja rakennamme kestäviä yhteisöjä teknologian avulla.',
    // Common words
    available: 'Saatavilla',
    claimed: 'Varattu',
    cancelled: 'Peruutettu',
    from: 'lähteestä',
    until: 'Asti',
    today: 'Tänään',
    tomorrow: 'Huomenna',
    request: 'Pyyntö',
    // Manual donation form specific
    quantityKg: 'Määrä (kg)',
    enterFoodName: 'Syötä ruoan nimi',
    enterQuantity: 'Syötä määrä',
    currentItemsInDonation: 'Ilmoituksen tämänhetkinen sisältö',
    addAnotherItem: 'Lisää toinen tuote',
    goBackToDashboard: 'Takaisin kotinäkymään',
    photosHelpIdentify: 'Kuvat auttavat tunnistamaan ruokalahjoituksesi',
    addPhotos: 'Lisää kuvia',
    addMore: 'Lisää lisää',
    uploading: 'Ladataan...',
    maxSizeMb: 'enintään 5MB/kuva',
    photosCount: 'kuvaa',
    enterDescription: 'Lisää tähän halutessasi tärkeää tietoa ruuasta, esim. Ei saa pakastaa uudelleen',
    savingEllipsis: 'Tallennetaan...',
    addItem: 'Jatka',
    // Recurring donation form specific
    approximateQuantityKg: 'Arvioitu määrä (kg)',
    pleaseDescribeFood: 'Kuvaile ruoka, jonka haluat lahjoittaa',
    foodDescriptionPlaceholderLong: 'esim., Tuoreita vihanneksia, valmisruokia, maitotuotteita...',
    quantityRequired: 'Määrä on pakollinen',
    quantityMinimum: 'Määrän tulee olla vähintään 1',
    enterValidNumber: 'Syötä kelvollinen numero',
    allergensAndDietaryInfo: 'Allergeenit ja ruokavalio-tiedot',
    gettingStarted: 'Aloittaminen',
    architecture: 'Arkkitehtuuri',
    development: 'Kehitys',
    deployment: 'Käyttöönotto',
    apiReference: 'API-viite',
    decisions: 'Päätökset',
    // Allergens options
    notSpecified: 'Ei määritelty',
    glutenFree: 'Gluteeniton',
    lactoseFree: 'Laktoositon',
    milkFree: 'Maidoton',
    lowLactose: 'Vähälaktoosinen',
    eggFree: 'Munaton',
    soyFree: 'Soijaton',
    noPeanuts: 'Sisältää maapähkinöitä',
    noOtherNuts: 'Sisältää muita pähkinöitä',
    noFish: 'Sisältää kalaa',
    noCrustaceans: 'Sisältää äyriäisiä',
    noCelery: 'Sisältää selleriä',
    noMustard: 'Sisältää sinappia',
    noSesamSeeds: 'Sisältää seesaminsiemeniä',
    noSulphurDioxide: 'Sisältää rikkidioksidia / sulfiitteja (>10 mg/kg)',
    noLupin: 'Sisältää lupiinia',
    noMolluscs: 'Sisältää nilviäisiä',
    // Request details page
    confirmForToday: 'Vahvista tänään',
    orderCompleted: 'Tilaus valmis',
    confirmed: 'Vahvistettu',
    seeAllRequests: 'Näytä kaikki pyynnöt',
    showMore: 'Näytä lisää',
    showLess: 'Näytä vähemmän',
    // Navigation & UI (New additions)
    zipli: 'Zipli',
    whatWouldYouLikeToDo: 'Mitä haluaisit tehdä?',
    donateOrSell: 'Lahjoita tai Myy',
    offerFoodItems: 'Tarjoa ruokatuotteita muille.',
    createRequestForItems: 'Luo pyyntö tietyille tuotteille.',
    returnToHome: 'Palaa etusivulle',
    apply: 'Käytä',
    // Dashboard Titles (New additions)
    foodDonorDashboard: 'Ruokalahjoittajan hallintapaneeli',
    welcomeDonorDashboard: 'Tervetuloa lahjoittajan hallintapaneeliin',
    foodReceiverDashboard: 'Ruoan vastaanottajan hallintapaneeli',
    cityDashboard: 'Kaupungin hallintapaneeli',
    terminalDashboard: 'Ruokaterminaalin hallintapaneeli',
    welcomeTerminalDashboard: 'Tervetuloa terminaalin hallintapaneeliin. Täällä voit:',
    // Dashboard Actions (New additions)
    listAvailableFood: 'Listaa saatavilla oleva ruoka',
    createNewDonations: 'Luo uusia lahjoituksia',
    trackDonationStatus: 'Seuraa lahjoituksen tilaa',
    managePickupSchedules: 'Hallitse noutoaikatauluja',
    processLargeScaleDonations: 'Käsittele suuria ruokalahjoituksia',
    coordinateWithMultiple: 'Koordinoi useiden lahjoittajien ja vastaanottajien kanssa',
    manageFoodStorage: 'Hallitse ruoan varastointia ja jakelua',
    trackProcessingCapacity: 'Seuraa käsittelykeskuksen kapasiteettia',
    // Form Labels & Placeholders (New additions)
    eg10: 'esim. 10',
    ringDoorbell: 'Ole hyvä ja soita ovikelloa',
    searchRequests: 'Hae pyyntöjä...',
    enter6DigitCode: 'Syötä 6-numeroinen koodi',
    enterNewPassword: 'Syötä uusi salasana',
    // Status & Messages (New additions)
    noRequestDataFound: 'Pyyntötietoja ei löytynyt',
    qrCodeUnavailable: 'QR-koodi ei saatavilla',
    notEnoughDataPoints: 'Ei tarpeeksi datapisteitä käyrän piirtämiseen',
    didntReceiveCode: 'Etkö saanut koodia?',
    uploadedPreview: 'Ladattu esikatselu',
    placeholderImage: 'Paikkamerkki kuva',
    noImage: 'Ei kuvaa',
    errorLoadingImage: 'Virhe kuvan lataamisessa',
    // Dialog Titles (New additions)
    cancelRequest: 'Peruuta pyyntö',
    confirmDelivery: 'Vahvista toimitus',
    areYouSure: 'Oletko varma?',
    confirmClaim: 'Kuittaa nouto',
    removeListing: 'Posta ilmoitus',
    yesRemove: 'Kyllä, poista',
    removing: 'Poistetaan...',
    removeListingDescription: 'Tämä poistaa ilmoituksen pysyvästi julkisesta näkyvyydestä. Tätä toimintoa ei voi kumota.',
    confirmClaimDescription: 'Vahvista, että lahjoitus on noudettu ja vastaanotettu.',
    confirmClaimClause: 'Vahvistan, että lahjoituksen lämpötilat on mitattu ja ruoka-aineet on säilytetty ruokaturvallisuusviranomaisten suositamien lämpötilojen sisällä. Kuittaan täten lahjoituksen noudetuksi.',
    confirmDeliveryDescription: 'Vahvista, että ruoka on toimitettu ja vastaanotettu onnistuneesti.',
    confirmDeliveryClause: 'Vahvistan, että toimituksen lämpötilat on mitattu ja ruoka-aineet on säilytetty ruokaturvallisuusviranomaisten suositamien lämpötilojen sisällä. Kuittaan täten toimituksen vastaanotetuksi.',
    editRequestPeriod: 'Muokkaa pyyntöjaksoa',
    editSchedule: 'Muokkaa aikataulua',
    editDeliveryTime: 'Muokkaa toimitusaikaa',
    deleteSchedule: 'Poista aikataulu',
    donationSummary: 'Ilmoituksen yhteenveto',
    donationItems: 'Ruoka-aineet ilmoituksessa',
    addressAndInstructions: 'Osoitetiedot & ohjeet',
    saveAddressToProfile: 'Tallenna muutokset profiiliin',
    saveInstructionsToProfile: 'Tallenna muutokset profiiliin',
    editPickupTime: 'Muokkaa noutoaikaa',
    confirmPickup: 'Kuittaa nouto',
    rememberToMarkPickedUp: 'Muista kuitata ruoka noudetuksi klikkaamalla lahjoituksen nimeä etusivun vihreässä ikkunassa',
    // Photo upload options
    photoOptions: 'Kuva-asetukset',
    takePhoto: 'Ota kuva',
    chooseFromGallery: 'Valitse galleriasta',
    cameraNotAvailable: 'Kamera ei käytettävissä',
    tapToTakePhotoOrChoose: 'Napauta ottaaksesi kuvan tai valitaksesi tiedoston',
    tapToChooseFile: 'Napauta valitaksesi tiedoston',
    dragDropOrClick: 'Vedä ja pudota tai klikkaa valitaksesi tiedostoja',
    supportedFormats: 'Tuetut formaatit: JPG, PNG, WebP',
    maxFileSize: 'Max',
    // User Roles (New additions - some already exist, adding missing ones)
    cityOfficial: 'Kaupungin virkamies',
    // Admin (New additions)
    users: 'Käyttäjät',
    totalUsers: 'Käyttäjät yhteensä',
    qrLogin: 'QR-kirjautuminen',
    // Additional form placeholders and labels
    addressPlaceholder: 'Syötä koko osoitteesi',
    contactNumberPlaceholder: 'Puhelinnumero',
    emailAddressPlaceholder: 'Sinun sähköpostisi',
    passwordPlaceholder: 'Sinun salasanasi',
    // Organization names (for reference, might not need translation)
    tsanssi: 'Tsänssi',
    redCross: 'Punainen Risti',
    andreasChurch: 'Andreas kirkko',
    helsinkiFoodTerminal: 'Helsingin ruokaterminaali',
    // Additional UI text (fixing cross-language issues)
    chooseRequestType: 'Valitse tarpeisiisi parhaiten sopiva tyyppi',
    note: 'Huomio',
    multipleRequestsNote: 'Voit luoda useita pyyntöjä tarpeidesi mukaan. Jokainen pyyntö sovitetaan saatavilla oleviin lahjoituksiin.',
    noActiveDonationsOrRequests: 'Sinulla ei ole aktiivisia lahjoituksia tai pyyntöjä',
    // New keys for fixing malformed text
    editRequest: 'Muokkaa pyyntöä',
    contactRequester: 'Ota yhteyttä pyytäjään',
    viewAll: 'Näytä kaikki',
    by: 'käyttäjältä',
    searchDonations: 'Hae lahjoituksia...',
    noDonationsAvailable: 'Lahjoituksia ei ole tällä hetkellä saatavilla',
    // Additional keys for thank-you and pickup-slot pages
    donationCreatedDesc: '',
    changesSavedDesc: 'Muutoksesi on tallennettu onnistuneesti.',
    addDeliveryTimeSlots: 'Lisää yksi tai useampi toimitusaika antaaksesi lahjoittajille joustavuutta.',
    // Missing weekday abbreviations
    sun: 'Su',
    mon: 'Ma',
    tue: 'Ti',
    wed: 'Ke',
    thu: 'To',
    fri: 'Pe',
    sat: 'La',
    // Missing scheduling keys
    everyDay: 'Päivittäin',
    setYourSchedule: 'Aseta aikataulu',
    select: 'Valitse',
    // Missing action keys
    anonymousRequester: 'Nimetön pyytäjä',
    created: 'Luotu',
    fulfilled: 'Täytetty',
    // Missing BottomNav keys
    foodItem: 'Ruoka-aine',
    // Missing helper text keys
    separateMultipleItems: 'Erota useammat kohteet pilkuilla tai uusilla riveillä',
    requestPeriodFrom: 'alkaen',
    requestPeriodTo: 'päättyen',
    // User input placeholders (New keys added)
    enterQuantityKg: 'Syötä määrä kiloina',
    allergenExampleText: 'esim. Gluteeniton, Laktoositon, Sisältää pähkinöitä',
    allStatuses: 'Kaikki tilat',
    // Alert messages (New keys added)
    enterAddress: 'Syötä osoitteesi',
    completeRequestDetails: 'Täydennä pyynnön tiedot',
    submissionFailed: 'Pyynnön lähetys epäonnistui',
    noDataReturned: 'Tietoja ei palautettu',
    unknownError: 'Tuntematon virhe',
    // Interface text (New keys added)
    updateRequest: 'Päivitä pyyntö',
    startNewRequest: 'Aloita uusi pyyntö',
    foodRequest: 'Ruokapyyntö',
    noneSpecified: 'Ei määritelty',
    unknownUser: 'Tuntematon käyttäjä',
    editStartDate: 'Muokkaa aloituspäivää',
    // Section headers (New keys added)
    pickupSlots: 'Noutoajankohdat',
    foodRequests: 'Ruokapyynnöt',
    // Error messages (New keys added)
    requestNotFound: 'Pyyntöä ei löytynyt',
    loadingFailed: 'Lataus epäonnistui',
    updateFailed: 'Päivitys epäonnistui',
    noRequestsFoundSearch: 'Hakua vastaavia pyyntöjä ei löytynyt.',
    noRequestsAvailable: 'Pyyntöjä ei ole tällä hetkellä saatavilla.',
    noAdditionalInstructions: 'Lisäohjeita ei annettu.',
    genericError: 'Tapahtui virhe. Yritä uudelleen.',
    adjustFilters: 'Kokeile muuttaa hakuehtoja tai suodattimia',
    noRequestsYet: 'Et ole vielä luonut yhtään pyyntöä',
    // Additional UI text
    startNewDonation: 'Aloita uusi lahjoitus',
    people: 'henkilöä',
    itemProgress: 'Kohde {current} / {total}',
    // PDF and file names
    donationSummaryTitle: 'Zipli Lahjoitusyhteenveto',
    requestSummaryTitle: 'Zipli Pyyntöyhteenveto',
    donationSummaryFilename: 'zipli-lahjoitus.pdf',
    receiverSummaryFilename: 'zipli-vastaanottaja.pdf',
    // Modal text (new keys added)
    keepRequest: 'Säilytä pyyntö',
    cancelRequestConfirmation: 'Haluatko varmasti peruuttaa tämän pyynnön? Tätä toimintoa ei voi kumota.',
    // Accessibility labels (new keys only)
    // noImage and editPickupTime already exist above
    // Terminal Dashboard specific
    operationsOverview: 'Toimintojen yleiskatsaus',
    currentStatusAndMetrics: 'Nykyinen tila ja reaaliaikaiset mittarit',
    volumeProcessed: 'Käsitelty volyymi',
    storageUtilization: 'Varastotason käyttö',
    processingEfficiency: 'Käsittelyn tehokkuus',
    activeRoutes: 'Aktiiviset reitit',
    totalKilos: 'Käsitelty volyymi',
    activeOrganizations: 'Aktiiviset organisaatiot',
    estimatedCO2: 'Arvioitu CO₂-säästö',
    upcoming: 'Tulevat',
    nextPickupsDeliveries: 'Seuraavat noudot ja toimitukset',
    noUpcomingItems: 'Ei tulevia kohteita.',
    terminalOverviewSubtitle: 'Nopea yleiskatsaus terminaalille.',
    incomingDonations: 'Saapuvat lahjoitukset',
    deliveryRequests: 'Toimituspyynnöt',
    searchOrganizations: 'Hae organisaatioita, ruoka-aineita, kuvauksia...',
    allStatus: 'Kaikki tilat',
    received: 'Vastaanotettu',
    processing: 'Käsittelyssä',
    dispatched: 'Lähetetty',
    terminalFulfilled: 'Täytetty',
    exportData: 'Vie tiedot',
    donationProcessingDetails: 'Lahjoituksen käsittelyn tiedot',
    deliveryRequestDetails: 'Toimituspyynnön tiedot',
    noDonationsMatchFilters: 'Ei lahjoituksia suodattimillesi',
    noRequestsMatchFilters: 'Ei pyyntöjä suodattimillesi',
    organization: 'Organisaatio',
    processingStatus: 'Käsittelyn tila',
    foodItems: 'Ruoka-aineet',
    routeId: 'Reittitunnus',
    location: 'Sijainti',
    pickupDate: 'Noutopäivä',
    pickupTime: 'Noutoaika',
    status: 'Tila',
    urgency: 'Kiireellisyys',
    terminalPeopleCount: 'Henkilömäärä',
    deliveryWindow: 'Toimitusaika',
    assignedRoute: 'Määritetty reitti',
    items: 'kohdetta',
    terminalPeople: 'henkilöä',
    low: 'Matala',
    medium: 'Keskitaso',
    high: 'Korkea'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/translations/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// Static translations system
// Simple, reliable, and easy to maintain
__turbopack_context__.s([
    "getTranslations",
    ()=>getTranslations,
    "translations",
    ()=>translations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/translations/en.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$fi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/translations/fi.ts [app-client] (ecmascript)");
;
;
;
;
const getTranslations = (language)=>{
    return language === 'en' ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["en"] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$fi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fi"];
};
const translations = {
    en: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["en"],
    fi: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$fi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fi"]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useTranslations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Simple translation hook
// Replaces the complex i18n system with static imports
__turbopack_context__.s([
    "useCommonTranslation",
    ()=>useCommonTranslation,
    "useTranslations",
    ()=>useTranslations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useLanguage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/lib/translations/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const useTranslations = ()=>{
    _s();
    const { language } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$translations$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getTranslations"])(language);
    return {
        t,
        language
    };
};
_s(useTranslations, "d1ORxvPBup+C3Qetit/BVjvgCJk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
const useCommonTranslation = ()=>{
    _s1();
    const { t, language } = useTranslations();
    return {
        t: (key)=>{
            var _key;
            // Allow any string key, return translation or fallback to key
            // Use ?? instead of || to allow empty strings
            return (_key = t[key]) !== null && _key !== void 0 ? _key : key;
        },
        language
    };
};
_s1(useCommonTranslation, "t4P/dD+gnAof/eJQP644ANhZk6Q=", false, function() {
    return [
        useTranslations
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/BottomNav.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BottomNav
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/drawer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useTranslations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useTranslations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/store/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript) <export useSupabaseDatabase as useDatabase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bar$2d$chart$2d$3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bar-chart-3.js [app-client] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-grid.js [app-client] (ecmascript) <export default as LayoutGrid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$bag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBag$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shopping-bag.js [app-client] (ecmascript) <export default as ShoppingBag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trending-up.js [app-client] (ecmascript) <export default as TrendingUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
function BottomNav() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { currentUser } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useTranslations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCommonTranslation"])();
    // Define navigation items based on user role
    const navItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BottomNav.useMemo[navItems]": ()=>{
            if (!currentUser) return [];
            const role = currentUser.role;
            switch(role){
                case 'food_donor':
                    return [
                        {
                            href: '/donate',
                            label: t('dashboard'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__["LayoutGrid"]
                        },
                        {
                            href: '#',
                            label: t('add'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"],
                            isCentral: true
                        },
                        {
                            href: '/impact',
                            label: t('impact'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"]
                        }
                    ];
                case 'food_receiver':
                    return [
                        {
                            href: '/receiver/dashboard',
                            label: t('dashboard'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__["LayoutGrid"]
                        },
                        {
                            href: '#',
                            label: t('request'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"],
                            isCentral: true
                        },
                        {
                            href: '/impact',
                            label: t('impact'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"]
                        }
                    ];
                case 'city':
                    return [
                        {
                            href: '/city/dashboard',
                            label: t('dashboard'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__["LayoutGrid"]
                        },
                        {
                            href: '/city',
                            label: t('analytics'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bar$2d$chart$2d$3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"]
                        },
                        {
                            href: '/feed',
                            label: t('overview'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"]
                        }
                    ];
                case 'terminals':
                    return [
                        {
                            href: '/terminal/dashboard',
                            label: t('dashboard'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__["LayoutGrid"]
                        },
                        {
                            href: '/feed',
                            label: t('overview'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"]
                        }
                    ];
                default:
                    return [
                        {
                            href: '/donate',
                            label: t('dashboard'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$grid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutGrid$3e$__["LayoutGrid"]
                        },
                        {
                            href: '#',
                            label: t('add'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"],
                            isCentral: true
                        },
                        {
                            href: '/feed',
                            label: t('explore'),
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"]
                        }
                    ];
            }
        }
    }["BottomNav.useMemo[navItems]"], [
        currentUser,
        t
    ]);
    // Only render for authenticated users and exclude admin pages and form flows
    if (!currentUser || pathname.includes('/admin/') || pathname.includes('/auth/') || pathname.includes('/donate/manual') || pathname.includes('/donate/recurring-form') || pathname.includes('/donate/schedule') || pathname.includes('/donate/schedule-simple') || pathname.includes('/donate/recurring-schedule') || pathname.includes('/donate/pickup-slot') || pathname.includes('/donate/summary') || pathname.includes('/request/') || pathname.includes('/profile/')) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: "fixed bottom-0 left-0 z-40 w-full h-[76px] border-t border-primary-10 bg-base shadow-[0_-2px_10px_-5px_rgba(0,0,0,0.1)]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto grid grid-cols-3 h-full max-w-lg items-center",
            children: navItems.map((item, index)=>renderNavItem(item, index))
        }, void 0, false, {
            fileName: "[project]/src/components/BottomNav.tsx",
            lineNumber: 104,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/BottomNav.tsx",
        lineNumber: 103,
        columnNumber: 5
    }, this);
    //TURBOPACK unreachable
    ;
    // Helper function to render nav items to avoid repetition
    function renderNavItem(item, index) {
        const isActive = pathname === item.href && !item.isCentral;
        if (item.isCentral) {
            // For donors, navigate directly to /donate/manual (no modal)
            if ((currentUser === null || currentUser === void 0 ? void 0 : currentUser.role) === 'food_donor') {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>router.push('/donate/manual'),
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('group inline-flex flex-col items-center justify-center text-center w-full', '-mt-8'),
                    "aria-label": item.label,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-1 flex h-14 w-14 items-center justify-center rounded-full bg-lime text-primary shadow-md group-hover:bg-lime/90",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                className: "h-7 w-7",
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/src/components/BottomNav.tsx",
                                lineNumber: 127,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/BottomNav.tsx",
                            lineNumber: 126,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-caption font-medium text-primary'),
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/src/components/BottomNav.tsx",
                            lineNumber: 129,
                            columnNumber: 13
                        }, this)
                    ]
                }, item.label, true, {
                    fileName: "[project]/src/components/BottomNav.tsx",
                    lineNumber: 117,
                    columnNumber: 11
                }, this);
            }
            // For other roles, show the modal
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Drawer"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerTrigger"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('group inline-flex flex-col items-center justify-center text-center w-full', '-mt-8'),
                            "aria-label": item.label,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-1 flex h-14 w-14 items-center justify-center rounded-full bg-lime text-primary shadow-md group-hover:bg-lime/90",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                        className: "h-7 w-7",
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BottomNav.tsx",
                                        lineNumber: 148,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BottomNav.tsx",
                                    lineNumber: 147,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-caption font-medium text-primary'),
                                    children: item.label
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BottomNav.tsx",
                                    lineNumber: 150,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/BottomNav.tsx",
                            lineNumber: 140,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/BottomNav.tsx",
                        lineNumber: 139,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerContent"], {
                        className: "bg-base",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerHeader"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerTitle"], {
                                    className: "text-center",
                                    children: (currentUser === null || currentUser === void 0 ? void 0 : currentUser.role) === 'food_receiver' ? t('createRequest') : (currentUser === null || currentUser === void 0 ? void 0 : currentUser.role) === 'city' ? t('analytics') : t('donate')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BottomNav.tsx",
                                    lineNumber: 157,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BottomNav.tsx",
                                lineNumber: 156,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid gap-3 p-6 pt-2",
                                children: (currentUser === null || currentUser === void 0 ? void 0 : currentUser.role) === 'food_receiver' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "secondary",
                                                size: "lg",
                                                className: "w-full justify-start py-5 text-left",
                                                onClick: ()=>{
                                                    // Clear any existing form data for fresh start
                                                    if ("TURBOPACK compile-time truthy", 1) {
                                                        localStorage.removeItem('zipli-request-store');
                                                        sessionStorage.removeItem('pendingRequest');
                                                    }
                                                    router.push('/request/one-time-form');
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                        className: "mr-3 h-5 w-5 text-primary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 182,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "font-semibold text-primary",
                                                                children: t('oneTimeRequest')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 184,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-secondary",
                                                                children: t('createSingleRequest')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 187,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 183,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                lineNumber: 169,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/BottomNav.tsx",
                                            lineNumber: 168,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "secondary",
                                                size: "lg",
                                                className: "w-full justify-start py-5 text-left",
                                                onClick: ()=>{
                                                    // Clear any existing form data for fresh start
                                                    if ("TURBOPACK compile-time truthy", 1) {
                                                        localStorage.removeItem('zipli-request-store');
                                                        sessionStorage.removeItem('pendingRequest');
                                                    }
                                                    router.push('/request/recurring-form');
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                        className: "mr-3 h-5 w-5 text-primary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 207,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "font-semibold text-primary",
                                                                children: t('recurringRequest')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 209,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-secondary",
                                                                children: t('setupRepeatingSchedule')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 212,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 208,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                lineNumber: 194,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/BottomNav.tsx",
                                            lineNumber: 193,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true) : (currentUser === null || currentUser === void 0 ? void 0 : currentUser.role) === 'city' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerClose"], {
                                        asChild: true,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "secondary",
                                            size: "lg",
                                            className: "w-full justify-start py-5 text-left",
                                            onClick: ()=>router.push('/city/dashboard'),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bar$2d$chart$2d$3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                                                    className: "mr-3 h-5 w-5 text-primary"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/BottomNav.tsx",
                                                    lineNumber: 228,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "font-semibold text-primary",
                                                            children: t('analytics')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/BottomNav.tsx",
                                                            lineNumber: 230,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-secondary",
                                                            children: [
                                                                t('overview'),
                                                                "."
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/BottomNav.tsx",
                                                            lineNumber: 233,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/BottomNav.tsx",
                                                    lineNumber: 229,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/BottomNav.tsx",
                                            lineNumber: 222,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BottomNav.tsx",
                                        lineNumber: 221,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "secondary",
                                                size: "lg",
                                                className: "w-full justify-start py-5 text-left",
                                                onClick: ()=>router.push('/donate/manual'),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$bag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingBag$3e$__["ShoppingBag"], {
                                                        className: "mr-3 h-5 w-5 text-primary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 249,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "font-semibold text-primary",
                                                                children: [
                                                                    t('donate'),
                                                                    " ",
                                                                    t('foodItem')
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 251,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-secondary",
                                                                children: [
                                                                    t('createDonation'),
                                                                    "."
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 254,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 250,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                lineNumber: 243,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/BottomNav.tsx",
                                            lineNumber: 242,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerClose"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "secondary",
                                                size: "lg",
                                                className: "w-full justify-start py-5 text-left",
                                                onClick: ()=>router.push('/donate/recurring-form'),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                        className: "mr-3 h-5 w-5 text-primary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 267,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "font-semibold text-primary",
                                                                children: t('recurringDonation')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 269,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-secondary",
                                                                children: t('setupRepeatingSchedule')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                                lineNumber: 272,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/BottomNav.tsx",
                                                        lineNumber: 268,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BottomNav.tsx",
                                                lineNumber: 261,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/BottomNav.tsx",
                                            lineNumber: 260,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BottomNav.tsx",
                                lineNumber: 165,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerFooter"], {
                                className: "pt-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DrawerClose"], {
                                    asChild: true,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "ghost",
                                        size: "sm",
                                        children: t('cancel')
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BottomNav.tsx",
                                        lineNumber: 283,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BottomNav.tsx",
                                    lineNumber: 282,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BottomNav.tsx",
                                lineNumber: 281,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/BottomNav.tsx",
                        lineNumber: 155,
                        columnNumber: 11
                    }, this)
                ]
            }, item.label, true, {
                fileName: "[project]/src/components/BottomNav.tsx",
                lineNumber: 138,
                columnNumber: 9
            }, this);
        }
        // Regular nav items (Dashboard, Explore)
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: item.href,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('group inline-flex flex-col items-center justify-center text-center w-full h-full', 'px-1 hover:bg-primary-10'),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-col items-center justify-center w-full rounded-lg py-2', isActive ? 'bg-cream' : 'bg-transparent'),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('mb-1 h-5 w-5 text-primary-50 group-hover:text-primary', isActive && 'text-primary'),
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BottomNav.tsx",
                        lineNumber: 308,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-[10px]', isActive ? 'text-primary font-semibold' : 'text-primary-50', 'group-hover:text-primary'),
                        children: item.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/BottomNav.tsx",
                        lineNumber: 315,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BottomNav.tsx",
                lineNumber: 302,
                columnNumber: 9
            }, this)
        }, item.label, false, {
            fileName: "[project]/src/components/BottomNav.tsx",
            lineNumber: 294,
            columnNumber: 7
        }, this);
    }
}
_s(BottomNav, "XK17EBBMvfVQnKUQ1eaHvzfguoc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useTranslations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCommonTranslation"]
    ];
});
_c = BottomNav;
var _c;
__turbopack_context__.k.register(_c, "BottomNav");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useLayoutConfig.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLayoutConfig",
    ()=>useLayoutConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const useLayoutConfig = ()=>{
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    // Single source of truth for flow pages that should hide bottom nav
    const flowRegex = /^\/(donate|request)\/(new|manual|pickup-slot|schedule|summary|thank-you|success|detail|one-time-form|recurring-form|select-type|[^/]+\/handover-confirm)/;
    const isFlowPage = flowRegex.test(pathname) || pathname === '/profile' || pathname === '/feedback' || pathname === '/contact';
    // Desktop dashboards should not show bottom navigation
    const isDesktopDashboard = pathname === '/city/dashboard' || pathname === '/terminal/dashboard' || pathname === '/terminal/profile';
    const hideBottomNav = isFlowPage || isDesktopDashboard;
    return {
        showBottomNav: !hideBottomNav,
        // For PageContainer footer spacing
        needsBottomNavSpacing: !hideBottomNav
    };
};
_s(useLayoutConfig, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AppShell.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$auth$2f$AuthProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/auth/AuthProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/store/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript) <export useSupabaseDatabase as useDatabase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BottomNav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BottomNav.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLayoutConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useLayoutConfig.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useLanguage.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const AppShell = (param)=>{
    let { children } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const init = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])({
        "AppShell.useDatabase[init]": (state)=>state.init
    }["AppShell.useDatabase[init]"]);
    const { showBottomNav } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLayoutConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutConfig"])();
    const { language } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    // Initialize store for all routes (auth routes need it too for DevLoginSwitcher)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppShell.useEffect": ()=>{
            console.log('🔧 AppShell initializing store...');
            init();
        }
    }["AppShell.useEffect"], [
        init
    ]);
    // Set document language
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppShell.useEffect": ()=>{
            if (typeof document !== 'undefined') {
                document.documentElement.lang = language;
            }
        }
    }["AppShell.useEffect"], [
        language
    ]);
    const isAuthRoute = pathname === '/' || pathname.startsWith('/auth');
    const isDocsRoute = pathname.startsWith('/docs');
    const isDesktopDashboard = pathname === '/city/dashboard' || pathname.startsWith('/terminal');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$auth$2f$AuthProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthProvider"], {
        children: isAuthRoute ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                ' ',
                children
            ]
        }, void 0, true) : isDocsRoute || isDesktopDashboard ? /* Full-width layout for documentation pages and terminal desktop views */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-[100svh] bg-gray-50",
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/AppShell.tsx",
            lineNumber: 48,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)) : /* Layout: A mobile-like container centered on all screen sizes */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-[100svh] bg-cream",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative mx-auto flex h-[100svh] w-full max-w-lg flex-col bg-base shadow-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                        className: "flex-grow overflow-y-auto",
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/src/components/AppShell.tsx",
                        lineNumber: 54,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    showBottomNav && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BottomNav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/AppShell.tsx",
                        lineNumber: 56,
                        columnNumber: 31
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/AppShell.tsx",
                lineNumber: 52,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/AppShell.tsx",
            lineNumber: 51,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/AppShell.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AppShell, "aXjoqxi+cJOpOmCE+dEXAUZpfqs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLayoutConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutConfig"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = AppShell;
const __TURBOPACK__default__export__ = AppShell;
var _c;
__turbopack_context__.k.register(_c, "AppShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ErrorBoundary.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useLanguage.ts [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
class ErrorBoundary extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Component {
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        // Log error to monitoring service in production
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
    }
    render() {
        if (this.state.hasError && this.state.error) {
            const FallbackComponent = this.props.fallback || DefaultErrorFallback;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FallbackComponent, {
                error: this.state.error,
                resetError: this.resetError
            }, void 0, false, {
                fileName: "[project]/src/components/ErrorBoundary.tsx",
                lineNumber: 44,
                columnNumber: 9
            }, this);
        }
        return this.props.children;
    }
    constructor(props){
        super(props), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "resetError", ()=>{
            this.setState({
                hasError: false,
                error: null
            });
        });
        this.state = {
            hasError: false,
            error: null
        };
    }
}
const DefaultErrorFallback = (param)=>{
    let { error, resetError } = param;
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-dvh flex items-center justify-center bg-cream p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-md w-full bg-white rounded-lg shadow-lg p-6 text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-16 h-16 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-8 h-8 text-red-600",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ErrorBoundary.tsx",
                                    lineNumber: 76,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/ErrorBoundary.tsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/ErrorBoundary.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-semibold text-gray-900 mb-2",
                            children: t('somethingWentWrong')
                        }, void 0, false, {
                            fileName: "[project]/src/components/ErrorBoundary.tsx",
                            lineNumber: 84,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 mb-4",
                            children: "Something went wrong. Please try again."
                        }, void 0, false, {
                            fileName: "[project]/src/components/ErrorBoundary.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        ("TURBOPACK compile-time value", "development") === 'development' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                            className: "mb-4 text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                    className: "cursor-pointer text-sm text-gray-500 hover:text-gray-700",
                                    children: "Show Error Details"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ErrorBoundary.tsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                    className: "mt-2 text-xs text-red-600 bg-red-50 p-2 rounded overflow-auto",
                                    children: [
                                        error.message,
                                        error.stack
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/ErrorBoundary.tsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ErrorBoundary.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ErrorBoundary.tsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: resetError,
                            className: "w-full bg-primary text-white py-2 px-4 rounded-lg hover:bg-primary/90 transition-colors",
                            children: "Try Again"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ErrorBoundary.tsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>window.location.href = '/',
                            className: "w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors",
                            children: "Go Home"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ErrorBoundary.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ErrorBoundary.tsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ErrorBoundary.tsx",
            lineNumber: 67,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ErrorBoundary.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(DefaultErrorFallback, "ot2YhC7pP10gRrIouBKIa40vomw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useLanguage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"]
    ];
});
_c = DefaultErrorFallback;
const __TURBOPACK__default__export__ = ErrorBoundary;
var _c;
__turbopack_context__.k.register(_c, "DefaultErrorFallback");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/dev/DevLoginSwitcher.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/store/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__ = __turbopack_context__.i("[project]/src/store/supabaseDatabaseStore.ts [app-client] (ecmascript) <export useSupabaseDatabase as useDatabase>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const DevLoginSwitcher = /*#__PURE__*/ _s(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_c = _s(()=>{
    _s();
    const { users, login, currentUser, fetchUsers, isInitialized, init } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"])();
    // Ensure store is initialized and users are fetched
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DevLoginSwitcher.useEffect": ()=>{
            if (!isInitialized) {
                init();
            } else if (users.length === 0) {
                fetchUsers();
            }
        }
    }["DevLoginSwitcher.useEffect"], [
        isInitialized,
        users.length,
        fetchUsers,
        init
    ]);
    const handleLogin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DevLoginSwitcher.useCallback[handleLogin]": async (user)=>{
            console.log('DevLoginSwitcher: Attempting login for:', user.email);
            try {
                // Use development login method which might be different
                const { setCurrentUser } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"].getState();
                await setCurrentUser(user.email);
                console.log('DevLoginSwitcher: Login successful for:', user.email);
                // Force a page refresh to ensure proper state
                window.location.href = '/';
            } catch (error) {
                console.error('DevLoginSwitcher login error:', error);
                // Fallback to regular login
                try {
                    const result = await login(user.email, 'password');
                    if (result.error) {
                        console.error('Translation key error', result.error);
                    } else {
                        console.log('DevLoginSwitcher: Fallback login successful');
                        window.location.href = '/';
                    }
                } catch (fallbackError) {
                    console.error('Translation key error', fallbackError);
                }
            }
        }
    }["DevLoginSwitcher.useCallback[handleLogin]"], [
        login
    ]);
    const userList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DevLoginSwitcher.useMemo[userList]": ()=>{
            // Sort users by role first, then by organization name
            const sortedUsers = [
                ...users
            ].sort({
                "DevLoginSwitcher.useMemo[userList].sortedUsers": (a, b)=>{
                    // First sort by role
                    const roleOrder = [
                        'food_donor',
                        'food_receiver',
                        'city_dashboard',
                        'terminal'
                    ];
                    const roleA = roleOrder.indexOf(a.role || '');
                    const roleB = roleOrder.indexOf(b.role || '');
                    if (roleA !== roleB) {
                        return roleA - roleB;
                    }
                    // Then sort by organization name or full name
                    const nameA = (a.organization_name || a.full_name || '').toLowerCase();
                    const nameB = (b.organization_name || b.full_name || '').toLowerCase();
                    return nameA.localeCompare(nameB);
                }
            }["DevLoginSwitcher.useMemo[userList].sortedUsers"]);
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "space-y-1 max-h-96 overflow-y-auto",
                children: sortedUsers.map({
                    "DevLoginSwitcher.useMemo[userList]": (user)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "w-full text-left px-2 py-1 rounded hover:bg-green-100 transition text-sm ".concat((currentUser === null || currentUser === void 0 ? void 0 : currentUser.id) === user.id ? 'bg-green-200 font-bold' : ''),
                                onClick: {
                                    "DevLoginSwitcher.useMemo[userList]": ()=>handleLogin(user)
                                }["DevLoginSwitcher.useMemo[userList]"],
                                disabled: (currentUser === null || currentUser === void 0 ? void 0 : currentUser.id) === user.id,
                                children: [
                                    user.organization_name || user.full_name,
                                    ' ',
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-400",
                                        children: [
                                            "(",
                                            user.role,
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                                        lineNumber: 88,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                                lineNumber: 82,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, user.id || user.email, false, {
                            fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                            lineNumber: 81,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                }["DevLoginSwitcher.useMemo[userList]"])
            }, void 0, false, {
                fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }["DevLoginSwitcher.useMemo[userList]"], [
        users,
        currentUser,
        handleLogin
    ]);
    // Log state for debugging purposes
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('DevLoginSwitcher: Users loaded:', users.length);
    }
    if (users.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed bottom-4 right-4 z-50 bg-white border border-gray-300 rounded-lg shadow-lg p-4 w-64",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "font-bold mb-2 text-sm text-gray-700",
                    children: "Dev User Switcher"
                }, void 0, false, {
                    fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                    lineNumber: 104,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-xs text-gray-500",
                    children: [
                        "No users found. Run",
                        ' ',
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                            className: "bg-gray-100 px-1 rounded",
                            children: "npm run seed"
                        }, void 0, false, {
                            fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        " to create test users."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                    lineNumber: 107,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
            lineNumber: 103,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-4 right-4 z-50 bg-white border border-gray-300 rounded-lg shadow-lg p-4 w-64",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "font-bold mb-2 text-sm text-gray-700",
                children: [
                    "Dev User Switcher (",
                    users.length,
                    " users)"
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
                lineNumber: 118,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            userList
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/dev/DevLoginSwitcher.tsx",
        lineNumber: 117,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
}, "ufM99elgq642nq8miXC4tw/OAPc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"]
    ];
})), "ufM99elgq642nq8miXC4tw/OAPc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$supabaseDatabaseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__useSupabaseDatabase__as__useDatabase$3e$__["useDatabase"]
    ];
});
_c1 = DevLoginSwitcher;
const __TURBOPACK__default__export__ = DevLoginSwitcher;
var _c, _c1;
__turbopack_context__.k.register(_c, "DevLoginSwitcher$React.memo");
__turbopack_context__.k.register(_c1, "DevLoginSwitcher");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/dev/DevSwitcherOverlay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DevSwitcherOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$dev$2f$DevLoginSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/dev/DevLoginSwitcher.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function DevSwitcherOverlay() {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const toggleOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DevSwitcherOverlay.useCallback[toggleOpen]": ()=>{
            setOpen({
                "DevSwitcherOverlay.useCallback[toggleOpen]": (v)=>!v
            }["DevSwitcherOverlay.useCallback[toggleOpen]"]);
        }
    }["DevSwitcherOverlay.useCallback[toggleOpen]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-4 right-4 z-[99]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$dev$2f$DevLoginSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/dev/DevSwitcherOverlay.tsx",
                    lineNumber: 16,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/dev/DevSwitcherOverlay.tsx",
                lineNumber: 15,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-label": open ? 'Hide dev switcher' : 'Show dev switcher',
                onClick: toggleOpen,
                className: "fixed z-[100] bg-gray-800 text-white rounded-full shadow-lg p-2 hover:bg-gray-700 transition-all duration-200 ".concat(open ? 'bottom-[280px] right-4' : 'bottom-4 right-4'),
                style: {
                    pointerEvents: 'auto'
                },
                children: open ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "▼"
                }, void 0, false, {
                    fileName: "[project]/src/components/dev/DevSwitcherOverlay.tsx",
                    lineNumber: 28,
                    columnNumber: 17
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "▲"
                }, void 0, false, {
                    fileName: "[project]/src/components/dev/DevSwitcherOverlay.tsx",
                    lineNumber: 28,
                    columnNumber: 41
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/dev/DevSwitcherOverlay.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(DevSwitcherOverlay, "Bkl4JBvVZsXpzv8SmKwItS3RzTQ=");
_c = DevSwitcherOverlay;
var _c;
__turbopack_context__.k.register(_c, "DevSwitcherOverlay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_c022b30c._.js.map