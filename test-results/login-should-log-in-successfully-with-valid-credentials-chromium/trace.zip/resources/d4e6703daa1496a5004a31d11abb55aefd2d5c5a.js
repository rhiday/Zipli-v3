(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_62d002f9._.js",
  "static/chunks/src_a240eca0._.js"
],
    source: "dynamic"
});
